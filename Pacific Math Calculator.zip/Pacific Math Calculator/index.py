#Project Name : Pacific Math Calculator .
#Author : Pamal Mangat.
#Start date : Wednesday, April 6th, 2016.

#Description : Basic Math Calculator with multiple functions.

#imports:
import tkinter
import time
from PIL import Image, ImageTk
import benchScript
import PMC_MAIN2

def start():

    baseGUI = tkinter.Tk()

    #Import a background image:
    backgroundImageImport = Image.open(r"mainMenu_Background.png")
    backgroundImageRender = ImageTk.PhotoImage(backgroundImageImport)
    backgroundImageDisplay = tkinter.Label(baseGUI, image=backgroundImageRender)
    backgroundImageDisplay.pack()

    #Imports a start button:
    startButtonImageImport = Image.open(r"startButton_Background.png")
    startButtonImageRender = ImageTk.PhotoImage(startButtonImageImport)
    startButton = tkinter.Button(baseGUI, width=250, height=65, image=startButtonImageRender, command=lambda:benchScript.transition(baseGUI, PMC_MAIN2.rootGUI))
    startButton.place(x=250, y=285)

    #Imports a quit button:
    quitButtonImageImport = Image.open(r"quitButton_Background.png")
    quitButtonImageRender = ImageTk.PhotoImage(quitButtonImageImport)
    quitButton = tkinter.Button(baseGUI, width=250, height=65, image=quitButtonImageRender, command=lambda:benchScript.quit_Application(baseGUI))
    quitButton.place(x=250, y=375)

    baseGUI.title("[Pacific Math Calculator]")
    baseGUI.geometry("750x525")
    baseGUI.resizable(False, False)
    baseGUI.after(100, lambda: baseGUI.focus_force())
    baseGUI.iconbitmap(r'PMC_ICO.ico')
    baseGUI.mainloop()

    return 0

start()


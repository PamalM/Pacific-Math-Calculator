#Sin, Cos, Tan Function:
#Start Date : Wednesday May 4th, 2016.
#Author: Pamal Mangat

import tkinter
from PIL import Image, ImageTk
import math
from time import sleep
from benchScript import *

def execute():

    def calculate():
        #Function calculates and prints out the answer:

        try:

            if switch.get() == 1 and alt_Switch.get() == 1:

                #If SIN. and DEG. mode are selected run this section:
                sin_Answer = round(math.sin(math.radians(float(textHolder.get()))), 4)

                answerGUI = tkinter.Toplevel()

                def closeTab(wW):
                    #wW = Which Window?
                    wW.destroy()
                    wW.quit()

                def watch_Enter_Key(event):

                    #If the enter key is pressed than close the answer GUI:

                    if event.keysym == "Return":
                        closeTab(answerGUI)

                #Imports a backgrond image/template:
                templateImport = Image.open(r"SCT_AnswerSkin.png")
                templateRender = ImageTk.PhotoImage(templateImport)
                templateDisplay = tkinter.Label(answerGUI, image=templateRender)
                templateDisplay.image = templateRender
                templateDisplay.pack()

                #Label display the answer:
                displayAnswer = tkinter.Label(answerGUI, text=sin_Answer, font="TimesNewRoman 38", bg="black", fg="White", width=6)
                displayAnswer.place(x=55, y=50)

                answerGUI.title("Answer:")
                answerGUI.geometry("300x175")
                answerGUI.resizable(False, False)
                answerGUI.after(1, lambda: answerGUI.focus_force())
                answerGUI.bind("<Return>", watch_Enter_Key)
                answerGUI.iconbitmap(r'PMC_ICO.ico')
                answerGUI.mainloop()

            elif switch.get() == 2 and alt_Switch.get() == 1:
                #If COS. and DEG. mode are selected run this section:
                cos_Answer = round(math.cos(math.radians(float(textHolder.get()))), 4)

                answerGUI = tkinter.Toplevel()

                def closeTab(wW):
                    #wW = Which Window?
                    wW.destroy()
                    wW.quit()

                def watch_Enter_Key(event):

                    #If the enter key is pressed than close the answer GUI:

                    if event.keysym == "Return":
                        closeTab(answerGUI)

                #Imports a backgrond image/template:
                templateImport = Image.open(r"SCT_AnswerSkin.png")
                templateRender = ImageTk.PhotoImage(templateImport)
                templateDisplay = tkinter.Label(answerGUI, image=templateRender)
                templateDisplay.image = templateRender
                templateDisplay.pack()

                #Label display the answer:
                displayAnswer = tkinter.Label(answerGUI, text=cos_Answer, font="TimesNewRoman 38", bg="black", fg="White", width=6)
                displayAnswer.place(x=55, y=50)

                answerGUI.title("Answer:")
                answerGUI.geometry("300x175")
                answerGUI.resizable(False, False)
                answerGUI.after(1, lambda: answerGUI.focus_force())
                answerGUI.bind("<Return>", watch_Enter_Key)
                answerGUI.iconbitmap(r'PMC_ICO.ico')
                answerGUI.mainloop()

            elif switch.get() == 3 and alt_Switch.get() == 1:
                #If TAN. and DEG. mode are selected run this section:
                tan_Answer = round(math.tan(math.radians(float(textHolder.get()))), 4)

                answerGUI = tkinter.Toplevel()

                def closeTab(wW):
                    #wW = Which Window?
                    wW.destroy()
                    wW.quit()

                def watch_Enter_Key(event):

                    #If the enter key is pressed than close the answer GUI:

                    if event.keysym == "Return":
                        closeTab(answerGUI)

                #Imports a backgrond image/template:
                templateImport = Image.open(r"SCT_AnswerSkin.png")
                templateRender = ImageTk.PhotoImage(templateImport)
                templateDisplay = tkinter.Label(answerGUI, image=templateRender)
                templateDisplay.image = templateRender
                templateDisplay.pack()

                #Label display the answer:
                displayAnswer = tkinter.Label(answerGUI, text=tan_Answer, font="TimesNewRoman 38", bg="black", fg="White", width=6)
                displayAnswer.place(x=55, y=50)

                answerGUI.title("Answer:")
                answerGUI.geometry("300x175")
                answerGUI.resizable(False, False)
                answerGUI.bind("<Return>", watch_Enter_Key)
                answerGUI.after(1, lambda: answerGUI.focus_force())
                answerGUI.bind("<Return>", watch_Enter_Key)
                answerGUI.iconbitmap(r'PMC_ICO.ico')
                answerGUI.mainloop()

            elif switch.get() == 1 and alt_Switch.get() == 2:
                #If SIN. and RAD. mode are selected run this section:
                sin_Answer = round(math.sin(float(textHolder.get())), 4)

                answerGUI = tkinter.Toplevel()

                def closeTab(wW):
                    #wW = Which Window?
                    wW.destroy()
                    wW.quit()

                def watch_Enter_Key(event):

                    #If the enter key is pressed than close the answer GUI:

                    if event.keysym == "Return":
                        closeTab(answerGUI)

                #Imports a backgrond image/template:
                templateImport = Image.open(r"SCT_AnswerSkin.png")
                templateRender = ImageTk.PhotoImage(templateImport)
                templateDisplay = tkinter.Label(answerGUI, image=templateRender)
                templateDisplay.image = templateRender
                templateDisplay.pack()

                #Label display the answer:
                displayAnswer = tkinter.Label(answerGUI, text=sin_Answer, font="TimesNewRoman 38", bg="black", fg="White", width=6)
                displayAnswer.place(x=55, y=50)

                answerGUI.title("Answer:")
                answerGUI.geometry("300x175")
                answerGUI.resizable(False, False)
                answerGUI.after(1, lambda: answerGUI.focus_force())
                answerGUI.bind("<Return>", watch_Enter_Key)
                answerGUI.iconbitmap(r'PMC_ICO.ico')
                answerGUI.mainloop()

            elif switch.get() == 2 and alt_Switch.get() == 2:
                #If COS. and RAD. mode are selected run this section:
                cos_Answer = round(math.cos(float(textHolder.get())), 4)

                answerGUI = tkinter.Toplevel()

                def closeTab(wW):
                    #wW = Which Window?
                    wW.destroy()
                    wW.quit()

                def watch_Enter_Key(event):

                    #If the enter key is pressed than close the answer GUI:

                    if event.keysym == "Return":
                        closeTab(answerGUI)

                #Imports a backgrond image/template:
                templateImport = Image.open(r"SCT_AnswerSkin.png")
                templateRender = ImageTk.PhotoImage(templateImport)
                templateDisplay = tkinter.Label(answerGUI, image=templateRender)
                templateDisplay.image = templateRender
                templateDisplay.pack()

                #Label display the answer:
                displayAnswer = tkinter.Label(answerGUI, text=cos_Answer, font="TimesNewRoman 38", bg="black", fg="White", width=6)
                displayAnswer.place(x=55, y=50)

                answerGUI.title("Answer:")
                answerGUI.geometry("300x175")
                answerGUI.resizable(False, False)
                answerGUI.after(1, lambda: answerGUI.focus_force())
                answerGUI.bind("<Return>", watch_Enter_Key)
                answerGUI.iconbitmap(r'PMC_ICO.ico')
                answerGUI.mainloop()

            elif switch.get() == 3 and alt_Switch.get() == 2:
                #If TAN. and RAD. mode are selected run this section:
                tan_Answer = round(math.tan(float(textHolder.get())), 4)

                answerGUI = tkinter.Toplevel()

                def closeTab(wW):
                    #wW = Which Window?
                    wW.destroy()
                    wW.quit()

                def watch_Enter_Key(event):

                    #If the enter key is pressed than close the answer GUI:

                    if event.keysym == "Return":
                        closeTab(answerGUI)

                #Imports a backgrond image/template:
                templateImport = Image.open(r"SCT_AnswerSkin.png")
                templateRender = ImageTk.PhotoImage(templateImport)
                templateDisplay = tkinter.Label(answerGUI, image=templateRender)
                templateDisplay.image = templateRender
                templateDisplay.pack()

                #Label display the answer:
                displayAnswer = tkinter.Label(answerGUI, text=tan_Answer, font="TimesNewRoman 38", bg="black", fg="White", width=6)
                displayAnswer.place(x=55, y=50)

                answerGUI.title("Answer:")
                answerGUI.geometry("300x175")
                answerGUI.resizable(False, False)
                answerGUI.after(1, lambda: answerGUI.focus_force())
                answerGUI.bind("<Return>", watch_Enter_Key)
                answerGUI.iconbitmap(r'PMC_ICO.ico')
                answerGUI.mainloop()

        except ValueError or NameError or SyntaxError as passed:

                def closeTab(whichWindow):
                    #Closes the current window:
                    whichWindow.destroy()
                    whichWindow.quit()

                #Create a new window to display answer:

                errorGUI = tkinter.Toplevel()

                #Imports a backgrond image/template:
                templateImport = Image.open(r"SCT_ErrorSkin.png")
                templateRender = ImageTk.PhotoImage(templateImport)
                templateDisplay = tkinter.Label(errorGUI, image=templateRender)
                templateDisplay.image = templateRender
                templateDisplay.pack()

                #Creates a button than (when clicked) closes the answer tab:
                closeButtonSkinImport = Image.open(r"QFC_AnswerCloseButtonSkin.png")
                closeButtonSkinRender = ImageTk.PhotoImage(closeButtonSkinImport)
                closeButton = tkinter.Button(errorGUI, image=closeButtonSkinRender, command=lambda:closeTab(errorGUI))
                closeButton.image = closeButtonSkinRender
                closeButton.focus()
                closeButton.place(x=186, y=122)

                errorGUI.title("Uh Oh!")
                errorGUI.geometry("300x175")
                errorGUI.resizable(False, False)
                errorGUI.after(1, lambda: errorGUI.focus_force())
                errorGUI.iconbitmap(r'PMC_ICO.ico')
                errorGUI.mainloop()

    def clear():
        #Function clears the main entry once the clear button is clicked:

        textHolder.set("")

        #Brings focus back to default buttons:
        sin_CHECK.select()
        deg_CHECK.select()

        #Set the HUD back to normal:
        templateDisplay.config(image=templateRender)
        templateDisplay_2nd.config(image=templateRender_2nd)

        SCT_GUI.update()

    def switch_HUD(id):
        #Function switches the hud depending on the function/method selected:

        if id == 1:
            #SIN.
            global templateRender1_
            templateImport1_ = Image.open(r"SCT_template1_.png")
            templateRender1_ = ImageTk.PhotoImage(templateImport1_)
            templateDisplay.config(image=templateRender1_)

        elif id == 2:
            #COS.
            global templateRender2_
            templateImport2_ = Image.open(r"SCT_template2_.png")
            templateRender2_ = ImageTk.PhotoImage(templateImport2_)
            templateDisplay.config(image=templateRender2_)

        elif id == 3:
            #TAN.
            global templateRender3_
            templateImport3_ = Image.open(r"SCT_template3_.png")
            templateRender3_ = ImageTk.PhotoImage(templateImport3_)
            templateDisplay.config(image=templateRender3_)

        elif id == "deg.":
            #DEG.
            global templateRenderDEG_
            templateImportDEG_ = Image.open(r"SCT_templateDEG_.png")
            templateRenderDEG_ = ImageTk.PhotoImage(templateImportDEG_)
            templateDisplay_2nd.config(image=templateRenderDEG_)

        elif id == "rad.":
            #RAD.
            global templateRenderRAD_
            templateImportRAD_ = Image.open(r"SCT_templateRAD_.png")
            templateRenderRAD_ = ImageTk.PhotoImage(templateImportRAD_)
            templateDisplay_2nd.config(image=templateRenderRAD_)

    def tab_Limiter(*args):
        #Limits the number of characters allowed to be entered into main entry field:

        if len(textHolder.get()) > 11:
            textHolder.set(textHolder.get()[:10])

    def alt_Func(cW):
        #cW : Close Window.
        #oP : Open Window.

        #Switches the user to the alt_invert tab function:
        cW.destroy()
        cW.quit()

        time.sleep(1)
        import SCT_Alt_Main
        SCT_Alt_Main.execute()

    def returnKey_Actor(event):
        #Function acts and directs the user to the calculation window when <enter> is pressed:

        if event.keysym == "Return":
            calculate()

    SCT_GUI = tkinter.Tk()

    #Imports a backgrond image/template:
    templateImport = Image.open(r"SCT_template1_.png")
    templateRender = ImageTk.PhotoImage(templateImport)
    templateDisplay = tkinter.Label(SCT_GUI, image=templateRender)
    templateDisplay.pack()

    #Imports a backgrond 2nd image/template:
    templateImport_2nd = Image.open(r"SCT_templateDEG_.png")
    templateRender_2nd = ImageTk.PhotoImage(templateImport_2nd)
    templateDisplay_2nd = tkinter.Label(SCT_GUI, image=templateRender_2nd, bd=0, highlightthickness=0)
    templateDisplay_2nd.place(x=105, y=67)

    #Tracker [Function trigger] variable:
    switch = tkinter.IntVar()

    #Tracker [Deg./Rad. identifier] variable:
    alt_Switch = tkinter.IntVar()

    #SIN. Checkbutton:
    sin_CHECK = tkinter.Radiobutton(SCT_GUI, bg="PeachPuff2", selectcolor="black", fg="red", font="TimesNewRoman 12", cursor="dot", variable=switch, value=1, command=lambda:switch_HUD(1))
    sin_CHECK.select()
    sin_CHECK.place(x=105, y=205)

    #COS. Checkbutton:
    cos_CHECK = tkinter.Radiobutton(SCT_GUI, bg="PeachPuff2", selectcolor="black", fg="red", font="TimesNewRoman 12", cursor="dot", variable=switch, value=2, command=lambda:switch_HUD(2))
    cos_CHECK.place(x=105, y=270)

    #TAN. Checkbutton:
    tan_CHECK = tkinter.Radiobutton(SCT_GUI, bg="PeachPuff2", selectcolor="black", fg="red", font="TimesNewRoman 12", cursor="dot", variable=switch, value=3, command=lambda:switch_HUD(3))
    tan_CHECK.place(x=105, y=335)

    #DEGREE Checkbutton:
    deg_CHECK = tkinter.Radiobutton(SCT_GUI, bg="PeachPuff2", selectcolor="black", fg="red", font="TimesNewRoman 12", cursor="dot", variable=alt_Switch, value=1, command=lambda:switch_HUD("deg."))
    deg_CHECK.select()
    deg_CHECK.place(x=380, y=80)

    #RADIAN Checkbutton:
    rad_CHECK = tkinter.Radiobutton(SCT_GUI, bg="PeachPuff2", selectcolor="black", fg="red", font="TimesNewRoman 12", cursor="dot", variable=alt_Switch, value=2, command=lambda:switch_HUD("rad."))
    rad_CHECK.place(x=470, y=80)

    textHolder = tkinter.StringVar()

    #Main textual display:
    textualDisplay = tkinter.Entry(SCT_GUI, width=12, font="TimesNewRoman 48", justify=tkinter.CENTER, textvariable=textHolder)
    textualDisplay.focus()
    textualDisplay.place(x=105, y=115)

    #Calculate/Equal button:
    equalButtonSkinImport = Image.open(r"SCT_CalculateButtonSkin.png")
    equalButtonSkinRender = ImageTk.PhotoImage(equalButtonSkinImport)
    equalButton = tkinter.Button(SCT_GUI, width=24, height=4, bg="black", text="=", fg="white", image=equalButtonSkinRender, command=lambda:calculate())
    equalButton.image = equalButtonSkinRender
    equalButton.config(width=140, height=65)
    equalButton.place(x=370, y=295)

    #Home Button:
    homeButtonSkinImport = Image.open(r"homeButtonSkin.png")
    homeButtonSkinRender = ImageTk.PhotoImage(homeButtonSkinImport)
    homeButton = tkinter.Button(SCT_GUI, bg="LightYellow2", fg="Red", image=homeButtonSkinRender, width=50, height=50, command=lambda:homeTravel(SCT_GUI))
    homeButton.place(x=575, y=375)

    #2nd calc. function (invert SIN, COS, TAN):
    ALTButtonSkinImport = Image.open(r"SCT_InvertButtonSkin.png")
    ALTButtonSkinRender = ImageTk.PhotoImage(ALTButtonSkinImport)
    ALTButton = tkinter.Button(SCT_GUI, width=24, height=4, bg="black", text="=", fg="white", image=ALTButtonSkinRender, command=lambda:alt_Func(SCT_GUI))
    ALTButton.image = ALTButtonSkinRender
    ALTButton.config(width=95, height=35)
    ALTButton.place(x=105, y=65)

    #Clear button:
    clearButtonSkinImport = Image.open(r"SCT_ClearButtonSkin.png")
    clearButtonSkinRender = ImageTk.PhotoImage(clearButtonSkinImport)
    clearButton = tkinter.Button(SCT_GUI, width=24, height=4, bg="black", text="=", fg="white", command=lambda:clear(), image=clearButtonSkinRender)
    clearButton.image = clearButtonSkinRender
    clearButton.config(width=140, height=65)
    clearButton.place(x=370, y=205)

    SCT_GUI.title("Trigonometry Function:")
    SCT_GUI.geometry("650x450")
    SCT_GUI.resizable(False, False)
    SCT_GUI.after(1, lambda: SCT_GUI.focus_force())
    textHolder.trace("w", tab_Limiter)
    SCT_GUI.bind("<Return>", returnKey_Actor)
    SCT_GUI.iconbitmap(r'PMC_ICO.ico')
    SCT_GUI.mainloop()

#Square Root Function:
#Start Date : Sunday, April 24th, 2016.
#Author: Pamal Mangat
#Finish date : Wednesday, May 4th, 2016.

import tkinter
from PIL import Image, ImageTk
import math
from time import sleep
from benchScript import *

invalid_Values = ['-']

try:
    def execute():

        def errorMessage():

            def closeTab(whichWindow):
                #Closes the current window:
                whichWindow.destroy()
                whichWindow.quit()

            #Create a new window to display answer:

            errorGUI = tkinter.Toplevel()

            #Imports a backgrond image/template:
            templateImport = Image.open(r"SQRT_ErrorSkin.png")
            templateRender = ImageTk.PhotoImage(templateImport)
            templateDisplay = tkinter.Label(errorGUI, image=templateRender)
            templateDisplay.image = templateRender
            templateDisplay.pack()

            #Creates a button than (when clicked) closes the answer tab:
            closeButtonSkinImport = Image.open(r"QFC_AnswerCloseButtonSkin.png")
            closeButtonSkinRender = ImageTk.PhotoImage(closeButtonSkinImport)
            closeButton = tkinter.Button(errorGUI, image=closeButtonSkinRender, command=lambda:closeTab(errorGUI))
            closeButton.image = closeButtonSkinRender
            closeButton.focus()
            closeButton.place(x=186, y=122)

            errorGUI.title("Uh Oh!")
            errorGUI.geometry("300x175")
            errorGUI.resizable(False, False)
            errorGUI.after(1, lambda: errorGUI.focus_force())
            errorGUI.iconbitmap(r'PMC_ICO.ico')
            errorGUI.mainloop()

        def calculate():
            #Calculate the square root of the entry tab.

            try:

                if indexHolder.get() == "":

                    try:
                        holder = float(tabHolder.get())
                        answer = (holder)**(1.0/2.0)

                        #Create a new window to display answer:

                        answerGUI = tkinter.Toplevel()

                        #Imports a backgrond image/template:
                        templateImport = Image.open(r"SQRT_AnswerSkin.png")
                        templateRender = ImageTk.PhotoImage(templateImport)
                        templateDisplay = tkinter.Label(answerGUI, image=templateRender)
                        templateDisplay.image = templateRender
                        templateDisplay.pack()

                        displayAnswer = tkinter.Label(answerGUI, text=round(answer,2), font="TimesNewRoman 38", bg="black", fg="White", width=5)
                        displayAnswer.place(x=70, y=70)

                        answerGUI.title("Answer:")
                        answerGUI.geometry("300x175")
                        answerGUI.resizable(False, False)
                        answerGUI.after(1, lambda: answerGUI.focus_force())
                        answerGUI.iconbitmap(r'PMC_ICO.ico')
                        answerGUI.mainloop()

                    except ValueError or TypeError as calculate_Error:
                        errorMessage()

                else:

                    try:
                        holder = float(tabHolder.get())
                        indexHold = float(indexHolder.get())
                        answer = (holder)**(1.0/(indexHold))

                        #Create a new window to display answer:

                        answerGUI = tkinter.Toplevel()

                        #Imports a backgrond imag324442424e/template:
                        templateImport = Image.open(r"SQRT_AnswerSkin.png")
                        templateRender = ImageTk.PhotoImage(templateImport)
                        templateDisplay = tkinter.Label(answerGUI, image=templateRender)
                        templateDisplay.image = templateRender
                        templateDisplay.pack()

                        displayAnswer = tkinter.Label(answerGUI, text=round(answer,2), font="TimesNewRoman 38", bg="black", fg="White", width=5)
                        displayAnswer.place(x=70, y=70)

                        answerGUI.title("Answer:")
                        answerGUI.geometry("300x175")
                        answerGUI.resizable(False, False)
                        answerGUI.after(1, lambda: answerGUI.focus_force())
                        answerGUI.iconbitmap(r'PMC_ICO.ico')
                        answerGUI.mainloop()

                    except ValueError or TypeError as calculate_Error2:
                        errorMessage()

            except ValueError and IndexError as passed:

                errorMessage()

        def clear():

            try:
                #Function clears all entries when event is triggered from the clear button:
                indexHolder.set("")
                index.config(bg="PeachPuff2", fg="Black")
                tabHolder.set("")
                tab.config(bg="PeachPuff2", fg="Black")

            except ValueError or IndexError or AttributeError or SyntaxError as error1:
                print('9999')

        def entry_Limit(*args):
            #Limits the amount of characters entered in the entry:

            if len(tabHolder.get()) >= 3:
                tabHolder.set(tabHolder.get()[:3])
                SR_GUI.update()

        def index_Watcher(*args):
            #Function keeps a watch on the index tab to only allow numbers and to make sure to limit to one integer only.

            if len(indexHolder.get()) >= 1:
                indexHolder.set(indexHolder.get()[:1])
                SR_GUI.update()
                tab.focus()

        def entry_Watch(event):

            if event.keysym == "Return":
                calculate()

        def colorTab(*args):

            if len(tabHolder.get()) >= 1:
                tab.config(bg="Snow", fg="Black")

        def colorIndex(*args):

            if len(indexHolder.get()) >= 0:
                index.config(bg="Snow", fg="Black")

        def index_Blocker(*args):
            #Prevents illegal characters from being entered into the entry:

            try:
                correct_Values = ['2', '3', '4', '5', '6', '7', '8', '9']

                if indexHolder.get() not in correct_Values:
                    indexHolder.set("")
                    SR_GUI.update()

            except ValueError as passed:
                pass

        def tab_Blocker(*args):
            #Prevents illegal characters from being entered into the entry:

            try:
                correct_Values = list(range(1000))

                if int(tabHolder.get()) not in correct_Values:
                    tabHolder.set("")
                    SR_GUI.update()

            except ValueError as passed:
                pass

        SR_GUI = tkinter.Tk()

        #Imports a backgrond image/template:
        templateImport = Image.open(r"SQRT_Template.png")
        templateRender = ImageTk.PhotoImage(templateImport)
        templateDisplay = tkinter.Label(SR_GUI, image=templateRender)
        templateDisplay.image = templateRender
        templateDisplay.pack()

        #Import the main entry:
        tabHolder = tkinter.StringVar()
        tab = tkinter.Entry(SR_GUI, font="TimesNewRoman 44", width=3, bd=4, bg="peachpuff2", fg="black", textvariable=tabHolder)
        tab.focus()
        tab.place(x=284, y=82)

        #Import the index entry:
        indexHolder = tkinter.StringVar()
        index = tkinter.Entry(SR_GUI, font="TimesNewRoman 22", width=1, bd=4, bg="peachpuff2", fg="black", textvariable=indexHolder)
        index.focus()
        index.place(x=194, y=42)
        #indexHolder.set(2)

        #Calculate/Equal button:
        equalButtonSkinImport = Image.open(r"SQRT_CalculateButtonSkin.png")
        equalButtonSkinRender = ImageTk.PhotoImage(equalButtonSkinImport)
        equalButton = tkinter.Button(SR_GUI, width=24, height=4, bg="black", text="=", fg="white", command=lambda:calculate(), image=equalButtonSkinRender)
        equalButton.image = equalButtonSkinRender
        equalButton.config(width=140, height=65)
        equalButton.place(x=290, y=230)

        #Clear button:
        clearButtonSkinImport = Image.open(r"SQRT_ClearButtonSkin.png")
        clearButtonSkinRender = ImageTk.PhotoImage(clearButtonSkinImport)
        clearButton = tkinter.Button(SR_GUI, width=24, height=4, bg="black", text="=", fg="white", command=lambda:clear(), image=clearButtonSkinRender)
        clearButton.image = clearButtonSkinRender
        clearButton.config(width=140, height=65)
        clearButton.place(x=130, y=230)

        #Home Button:
        homeButtonSkinImport = Image.open(r"homeButtonSkin.png")
        homeButtonSkinRender = ImageTk.PhotoImage(homeButtonSkinImport)
        homeButton = tkinter.Button(SR_GUI, bg="LightYellow2", fg="Red", image=homeButtonSkinRender, width=50, height=50, command=lambda:homeTravel(SR_GUI))
        homeButton.place(x=40, y=234)

        SR_GUI.title("Square Root Function:")
        SR_GUI.geometry("450x315")
        SR_GUI.resizable(False, False)
        tabHolder.trace("w", entry_Limit)
        indexHolder.trace("w", index_Watcher)
        indexHolder.trace("w", index_Blocker)
        tabHolder.trace("w", tab_Blocker)
        tabHolder.trace("w", colorTab)
        indexHolder.trace("w", colorIndex)
        SR_GUI.bind("<Return>" ,entry_Watch)
        SR_GUI.after(1, lambda: SR_GUI.focus_force())
        SR_GUI.iconbitmap(r'PMC_ICO.ico')
        SR_GUI.mainloop()

except AttributeError or ValueError or IndexError as defaultCase:
    pass

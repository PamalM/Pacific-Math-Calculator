#User clicks the calculator button in submenu and is directed to this function:
#<<<Basic Calculator>>>

import tkinter
from PIL import Image, ImageTk
from time import sleep
from benchScript import *
import math

def execute():

    def monitor_Key_Entry(event):

        #If the enter key is pressed than run the calculate method:
        if event.keysym == "Return":
            calculate()

        if event.keysym == "Escape":
            clearTab()

    def clearTab():
        #Empties/Clears the entire tab feild:
        tabHolder.set("")
        tab.update()

    def backSpace():
        #Function deletes the last number entered:
        entryTab = tabHolder.get()
        tabHolder.set(entryTab[:len(entryTab)-1])

    def valueEntry(id):

        if id != "negative":
            #Function enters numbers and operators into entry upon button press:
            currentValue = tabHolder.get()
            tabHolder.set(currentValue+id)
            tab.icursor(int(len(tabHolder.get())))
            tab.update()

        else:
            #If the small negative function button is pressed it needs it's own function:
            currentVal = tabHolder.get()
            tab.icursor(int(len(tabHolder.get())))
            tabHolder.set(currentVal+("(-"))
            tab.icursor(int(len(tabHolder.get())))

    def calculate():

        try:

            if len(tabHolder.get()) < 26:
                answer = eval(tabHolder.get())
                tabHolder.set(answer)

            else:
                tab.config(fg="Red", justify=tkinter.CENTER)
                tabHolder.set("MEMORY ERROR")

                tab.update()

                time.sleep(2)

                tabHolder.set("")
                tab.config(justify=tkinter.RIGHT, fg="Black")
                tab.update()

        #EXCEPT ALL THE POSSIBLE ERRORS AND HANDLE THEM WITH AN "ERROR" MESSAGE:

        except SyntaxError:
            tab.config(fg="Red", justify=tkinter.CENTER)
            tabHolder.set("ERROR")

            tab.update()

            time.sleep(2)

            tabHolder.set("")
            tab.config(justify=tkinter.RIGHT, fg="Black")
            tab.update()

        except NameError:
            tab.config(fg="Red", justify=tkinter.CENTER)
            tabHolder.set("ERROR")

            tab.update()

            time.sleep(2)

            tabHolder.set("")
            tab.config(justify=tkinter.RIGHT, fg="Black")
            tab.update()

        except ValueError:
            tab.config(fg="Red", justify=tkinter.CENTER)
            tabHolder.set("ERROR")

            tab.update()

            time.sleep(2)

            tabHolder.set("")
            tab.config(justify=tkinter.RIGHT, fg="Black")
            tab.update()

        except TypeError:
            tab.config(fg="Red", justify=tkinter.CENTER)
            tabHolder.set("ERROR")

            tab.update()

            time.sleep(2)

            tabHolder.set("")
            tab.config(justify=tkinter.RIGHT, fg="Black")
            tab.update()

    calcGUI = tkinter.Tk()

    #Imports a backgrond image/template:
    templateImport = Image.open(r"BC_template.png")
    templateRender = ImageTk.PhotoImage(templateImport)
    templateDisplay = tkinter.Label(calcGUI, image=templateRender)
    templateDisplay.image = templateRender
    templateDisplay.pack()

    #Import the text entry tab:
    tabHolder = tkinter.StringVar()
    tab = tkinter.Entry(calcGUI, width=24, font="ComicSansMS 27", textvariable=tabHolder, bd=4, relief=tkinter.RIDGE, insertwidth="3", justify=tkinter.RIGHT)
    tab.focus()
    tab.place(x=5, y=35)

    #Import all the buttons to be used:
    zeroButtonSkinImport = Image.open(r"BC_0ButtonSkin.png")
    zeroButtonSkinRender = ImageTk.PhotoImage(zeroButtonSkinImport)
    zeroButton = tkinter.Button(calcGUI, width=10, height=4, text="0", fg="black", command=lambda:valueEntry("0"), image=zeroButtonSkinRender)
    zeroButton.image = zeroButtonSkinRender
    zeroButton.config(width=75, height=65)
    zeroButton.place(x=115, y=510)

    decimalButtonSkinImport = Image.open(r"BC_DecimalButtonSkin.png")
    decimalButtonSkinRender = ImageTk.PhotoImage(decimalButtonSkinImport)
    decimalButton = tkinter.Button(calcGUI, width=10, height=4, text=".", fg="white", command=lambda:valueEntry("."), image=decimalButtonSkinRender)
    decimalButton.image = decimalButtonSkinRender
    decimalButton.config(width=75, height=65)
    decimalButton.place(x=210, y=510)

    oneButtonSkinImport = Image.open(r"BC_1ButtonSkin.png")
    oneButtonSkinRender = ImageTk.PhotoImage(oneButtonSkinImport)
    oneButton = tkinter.Button(calcGUI, width=10, height=4, text="1", fg="black", command=lambda:valueEntry("1"), image=oneButtonSkinRender)
    oneButton.image = oneButtonSkinRender
    oneButton.config(width=75, height=65)
    oneButton.place(x=20, y=413)

    twoButtonSkinImport = Image.open(r"BC_2ButtonSkin.png")
    twoButtonSkinRender = ImageTk.PhotoImage(twoButtonSkinImport)
    twoButton = tkinter.Button(calcGUI, width=10, height=4, text="2", fg="black", command=lambda:valueEntry("2"), image=twoButtonSkinRender)
    twoButton.image = twoButtonSkinRender
    twoButton.config(width=75, height=65)
    twoButton.place(x=115, y=413)

    threeButtonSkinImport = Image.open(r"BC_3ButtonSkin.png")
    threeButtonSkinRender = ImageTk.PhotoImage(threeButtonSkinImport)
    threeButton = tkinter.Button(calcGUI, width=10, height=4, text="3", fg="black", command=lambda:valueEntry("3"), image=threeButtonSkinRender)
    threeButton.image = threeButtonSkinRender
    threeButton.config(width=75, height=65)
    threeButton.place(x=210, y=413)

    fourButtonSkinImport = Image.open(r"BC_4ButtonSkin.png")
    fourButtonSkinRender = ImageTk.PhotoImage(fourButtonSkinImport)
    fourButton = tkinter.Button(calcGUI, width=10, height=4, text="4", fg="black", command=lambda:valueEntry("4"), image=fourButtonSkinRender)
    fourButton.image = fourButtonSkinRender
    fourButton.config(width=75, height=65)
    fourButton.place(x=20, y=316)

    fiveButtonSkinImport = Image.open(r"BC_5ButtonSkin.png")
    fiveButtonSkinRender = ImageTk.PhotoImage(fiveButtonSkinImport)
    fiveButton = tkinter.Button(calcGUI, width=10, height=4, text="5", fg="black", command=lambda:valueEntry("5"), image=fiveButtonSkinRender)
    fiveButton.image = fiveButtonSkinRender
    fiveButton.config(width=75, height=65)
    fiveButton.place(x=115, y=316)

    sixButtonSkinImport = Image.open(r"BC_6ButtonSkin.png")
    sixButtonSkinRender = ImageTk.PhotoImage(sixButtonSkinImport)
    sixButton = tkinter.Button(calcGUI, width=10, height=4, text="6", fg="black", command=lambda:valueEntry("6"), image=sixButtonSkinRender)
    sixButton.image = sixButtonSkinRender
    sixButton.config(width=75, height=65)
    sixButton.place(x=210, y=316)

    sevenButtonSkinImport = Image.open(r"BC_7ButtonSkin.png")
    sevenButtonSkinRender = ImageTk.PhotoImage(sevenButtonSkinImport)
    sevenButton = tkinter.Button(calcGUI, width=10, height=4, text="7", fg="black", command=lambda:valueEntry("7"), image=sevenButtonSkinRender)
    sevenButton.image = sevenButtonSkinRender
    sevenButton.config(width=75, height=65)
    sevenButton.place(x=20, y=219)

    eightButtonSkinImport = Image.open(r"BC_8ButtonSkin.png")
    eightButtonSkinRender = ImageTk.PhotoImage(eightButtonSkinImport)
    eightButton = tkinter.Button(calcGUI, width=10, height=4, text="8", fg="black", command=lambda:valueEntry("8"), image=eightButtonSkinRender)
    eightButton.image = eightButtonSkinRender
    eightButton.config(width=75, height=65)
    eightButton.place(x=115, y=219)

    nineButtonSkinImport = Image.open(r"BC_9ButtonSkin.png")
    nineButtonSkinRender = ImageTk.PhotoImage(nineButtonSkinImport)
    nineButton = tkinter.Button(calcGUI, width=10, height=4, text="9", fg="black", command=lambda:valueEntry("9"), image=nineButtonSkinRender)
    nineButton.image = nineButtonSkinRender
    nineButton.config(width=75, height=65)
    nineButton.place(x=210, y=219)

    clearButtonSkinImport = Image.open(r"BC_ClearButtonSkin.png")
    clearButtonSkinRender = ImageTk.PhotoImage(clearButtonSkinImport)
    clearButton = tkinter.Button(calcGUI, width=24, height=4, bg="black", text="CE", fg="white", command=lambda:clearTab(), image=clearButtonSkinRender)
    clearButton.image = clearButtonSkinRender
    clearButton.config(width=170, height=65)
    clearButton.place(x=20, y=122)

    equalButtonSkinImport = Image.open(r"BC_EqualButtonSkin.png")
    equalButtonSkinRender = ImageTk.PhotoImage(equalButtonSkinImport)
    equalButton = tkinter.Button(calcGUI, width=24, height=4, bg="black", text="=", fg="white", command=lambda:calculate(), image=equalButtonSkinRender)
    equalButton.image = equalButtonSkinRender
    equalButton.config(width=170, height=65)
    equalButton.place(x=305, y=510)

    multiplyButtonSkinImport = Image.open(r"BC_MultiplyButtonSkin.png")
    multiplyButtonSkinRender = ImageTk.PhotoImage(multiplyButtonSkinImport)
    multiplyButton = tkinter.Button(calcGUI, width=10, height=4, text="x", fg="white", command=lambda:valueEntry("*"), image=multiplyButtonSkinRender)
    multiplyButton.image = multiplyButtonSkinRender
    multiplyButton.config(width=75, height=65)
    multiplyButton.place(x=305, y=413)

    divideButtonSkinImport = Image.open(r"BC_DivideButtonSkin.png")
    divideButtonSkinRender = ImageTk.PhotoImage(divideButtonSkinImport)
    divideButton = tkinter.Button(calcGUI, width=10, height=4, text="/", fg="white", command=lambda:valueEntry("/"), image=divideButtonSkinRender)
    divideButton.image = divideButtonSkinRender
    divideButton.config(width=75, height=65)
    divideButton.place(x=400, y=413)

    subtractButtonSkinImport = Image.open(r"BC_SubtractButtonSkin.png")
    subtractButtonSkinRender = ImageTk.PhotoImage(subtractButtonSkinImport)
    subtractButton = tkinter.Button(calcGUI, width=10, height=4, text="-", fg="white", command=lambda:valueEntry("-"), image=subtractButtonSkinRender)
    subtractButton.image = subtractButtonSkinRender
    subtractButton.config(width=75, height=65)
    subtractButton.place(x=400, y=316)

    additionButtonSkinImport = Image.open(r"BC_AdditionButtonSkin.png")
    additionButtonSkinRender = ImageTk.PhotoImage(additionButtonSkinImport)
    additionButton = tkinter.Button(calcGUI, width=10, height=4, text="+", fg="white", command=lambda:valueEntry("+"), image=additionButtonSkinRender)
    additionButton.image = additionButtonSkinRender
    additionButton.config(width=75, height=65)
    additionButton.place(x=305, y=316)

    negativeButtonSkinImport = Image.open(r"BC_negativeBracketButtonSkin.png")
    negativeButtonSkinRender = ImageTk.PhotoImage(negativeButtonSkinImport)
    negativeButton = tkinter.Button(calcGUI, width=10, height=4, text="-", fg="White", command=lambda:valueEntry("negative"), image=negativeButtonSkinRender)
    negativeButton.image = negativeButtonSkinRender
    negativeButton.config(width=75, height=65)
    negativeButton.place(x=20, y=510)

    bracketOpenButtonSkinImport = Image.open(r"BC_OpenBracketButtonSkin.png")
    bracketOpenButtonSkinRender = ImageTk.PhotoImage(bracketOpenButtonSkinImport)
    bracketOpenButton = tkinter.Button(calcGUI, width=10, height=4, bg="black", text="(", fg="white", command=lambda:valueEntry("("), image=bracketOpenButtonSkinRender)
    bracketOpenButton.image = bracketOpenButtonSkinRender
    bracketOpenButton.config(width=75, height=65)
    bracketOpenButton.place(x=305, y=219)

    bracketCloseButtonSkinImport = Image.open(r"BC_CloseBracketButtonSkin.png")
    bracketCloseButtonSkinRender = ImageTk.PhotoImage(bracketCloseButtonSkinImport)
    bracketCloseButton = tkinter.Button(calcGUI, width=10, height=4, bg="black", text=")", fg="white", command=lambda:valueEntry(")"), image=bracketCloseButtonSkinRender)
    bracketCloseButton.image = bracketOpenButtonSkinRender
    bracketCloseButton.config(width=75, height=65)
    bracketCloseButton.place(x=400, y=219)

    backSpaceButtonSkinImport = Image.open(r"BC_BackSpaceButtonSkin.png")
    backSpaceButtonSkinRender = ImageTk.PhotoImage(backSpaceButtonSkinImport)
    backSpaceButton = tkinter.Button(calcGUI, width=10, height=4, bg="black", text="<--", fg="white", command=lambda:backSpace(), image=backSpaceButtonSkinRender)
    backSpaceButton.image = backSpaceButtonSkinRender
    backSpaceButton.config(width=75, height=65)
    backSpaceButton.place(x=210, y=122)

    power2ButtonSkinImport = Image.open(r"BC_Power2ButtonSkin.png")
    power2ButtonSkinRender = ImageTk.PhotoImage(power2ButtonSkinImport)
    power2Button = tkinter.Button(calcGUI, width=10, height=4, bg="black", text="**", fg="white", command=lambda:valueEntry("**"), image=power2ButtonSkinRender)
    power2Button.image = power2ButtonSkinRender
    power2Button.config(width=75, height=65)
    power2Button.place(x=305, y=122)

    #Home Button:
    homeButtonSkinImport = Image.open(r"homeButtonSkin.png")
    homeButtonSkinRender = ImageTk.PhotoImage(homeButtonSkinImport)
    homeButton = tkinter.Button(calcGUI, bg="LightYellow2", fg="Red", image=homeButtonSkinRender, width=50, height=50, command=lambda:homeTravel(calcGUI))
    homeButton.place(x=415, y=130)

    calcGUI.title("Pacific Math Calculator:")
    calcGUI.bind("<Return>", monitor_Key_Entry)
    calcGUI.bind("<Escape>", monitor_Key_Entry)
    #tabHolder.trace("w", limitEntry)
    calcGUI.geometry("500x600")
    calcGUI.resizable(False, False)
    calcGUI.iconbitmap(r'PMC_ICO.ico')
    calcGUI.after(100, lambda: calcGUI.focus_force())
    calcGUI.mainloop()


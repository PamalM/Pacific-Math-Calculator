import sys
from cx_Freeze import setup, Executable


build_exe_options = {"packages": ["os"], "include_files":["benchScript.py", "mainMenu_Background.png", "PMC_MAIN2.py", "QFC_equalsButtonSkin.png",
                     "QFC_Main.py", "QFC_Template.png", "quitButton_Background.png", "startButton_Background.png", "subMenu_Background.png",
                     "subMenu_QFCBootButtonImage.png", "subMenu_BCBootButtonImage.png", "QFC_HelpSkin.png", "QFC_ErrorSkin.png",
                     "QFC_ClearButtonSkin.png", "QFC_AnswerSkin.png", "QFC_AnswerCloseButtonSkin.png", "HomeButtonSkin.png", "helpButtonSkin.png",
                     "BC_Main.py", "BC_2ButtonSkin.png", "BC_7ButtonSkin.png", "BC_ClearButtonSkin.png", "BC_SubtractButtonSkin.png", "BC_3ButtonSkin.png",
                     "BC_8ButtonSkin.png", "BC_CloseBracketButtonSkin.png", "BC_MultiplyButtonSkin.png", "BC_Template.png", "subMenu_BCBootButtonImage.png",
                     "BC_4ButtonSkin.png", "BC_9ButtonSkin.png", "BC_DecimalButtonSkin.png", "BC_negativeBracketButtonSkin.png", "subMenu_SQRTBootButtonImage.png",
                     "SQRT_MAIN.py", "BC_Power2ButtonSkin.png", "BC_EqualButtonSkin.png", "BC_BackSpaceButtonSkin.png", "BC_6ButtonSkin.png", "BC_1ButtonSkin.png",
                     "BC_0ButtonSkin.png", "BC_5ButtonSkin.png", "BC_AdditionButtonSkin.png", "BC_DivideButtonSkin.png", "BC_OpenBracketButtonSkin.png",
                     "SQRT_Template.png", "SQRT_CalculateButtonSkin.png", "SQRT_ClearButtonSkin.png", "SQRT_ErrorSkin.png", "SQRT_AnswerSkin.png",
                     "SCT_Main.py", "SCT_templateRAD_.PNG", "SCT_AnswerSkin.png", "SCT_Template1_.png", "SCT_CalculateButtonSkin.png", "SCT_Template2_.png",
                     "subMenu_SCTBootButtonImage.png", "SCT_ClearButtonSkin.png", "SCT_Template3_.PNG", "SCT_ErrorSkin.png", "SCT_TemplateDEG_.png",
                     "SCT_Alt_Main.py", "SCT_Alt_Template1_.PNG", "SCT_Alt_Template2_.PNG", "SCT_Alt_Template3_.PNG", "SCT_InvertButtonSkin.png",
                     "SCT_ReturnButtonSkin.png", "mainMenu_Background.png", "PTC_Website_Button.png", "PTC_Courtesy_Button.png", "PTC_Background.png",
                     "PTC_Main.py", "SE_Help_Background.png", "SE_Error_Background.png", "subMenu_WebsiteImage.png", "PMC_ICO.ico", "PMC_ICON.png",
                     "subMenu_PTBootButtonImage.png", "PT_Background.png", "PT_ESB2_Background.png", "PT_ESB1_Background.png", "PT_Main.py",
                     "PT_SE_MAIN.py", "SE_Answer_Background.png", "SE_BackButton_Skin.png", "SE_RefreshButton_Skin.png", "SE_HelpButton_Skin.png",
                     "SE_SearchButton_Skin.png", "SE_Background.png", "SCT_Alt_ErrorSkin.png"]}

base = None
if sys.platform == "win32":
    base = "Win32GUI"

exe=Executable(
     script="index.py",
     base=base
     )

setup(  name = "Pacific Math Calculator",
        version = "1.00",
        description = "Your best friend when it comes to math assistance!",
        options = {"build_exe": build_exe_options},
        executables = [exe])

#Window provides options for the user.
#User picks function they would like to enter.
#Clicking the start button will bring you to this menu (sub-menu).

#Imports:
import tkinter
from PIL import ImageTk, Image
import time
from benchScript import *
from math import sqrt, log

def rootGUI():
    rootGUI = tkinter.Tk()

    #Import a background image:
    backgroundImageImport = Image.open(r"subMenu_Background.png")
    backgroundImageRender = ImageTk.PhotoImage(backgroundImageImport)
    backgroundImageDisplay = tkinter.Label(rootGUI, image=backgroundImageRender)
    backgroundImageDisplay.place(x=-2)

    #Calculator Function Button:
    CALCFUNC_backgroundImageImport = Image.open(r"subMenu_BCBootButtonImage.png")
    CALCFUNC_backgroundImageRender = ImageTk.PhotoImage(CALCFUNC_backgroundImageImport)
    calcForm_Button = tkinter.Button(rootGUI, width=195, height=45, command=lambda:function_Tunnel(1, rootGUI), image=CALCFUNC_backgroundImageRender)
    calcForm_Button.image = CALCFUNC_backgroundImageRender
    calcForm_Button.place(x=25, y=105)

    #Quadratic Formula Function Button:
    QFCFUNC_backgroundImageImport = Image.open(r"subMenu_QFCBootButtonImage.png")
    QFCFUNC_backgroundImageRender = ImageTk.PhotoImage(QFCFUNC_backgroundImageImport)
    quadForm_Button = tkinter.Button(rootGUI, width=195, height=45, command=lambda:function_Tunnel(2, rootGUI), image=QFCFUNC_backgroundImageRender)
    quadForm_Button.image = QFCFUNC_backgroundImageRender
    quadForm_Button.place(x=25, y=185)

    #Square Root Function Button:
    SQRTFUNC_backgroundImageImport = Image.open(r"subMenu_SQRTBootButtonImage.png")
    SQRTFUNC_backgroundImageRender = ImageTk.PhotoImage(SQRTFUNC_backgroundImageImport)
    sqrtForm_Button = tkinter.Button(rootGUI, width=195, height=45, command=lambda:function_Tunnel(3, rootGUI), image=SQRTFUNC_backgroundImageRender)
    sqrtForm_Button.image = SQRTFUNC_backgroundImageRender
    sqrtForm_Button.place(x=25, y=265)

    #Sin, Cos, Tan Function Button:
    SCTFUNC_backgroundImageImport = Image.open(r"subMenu_SCTBootButtonImage.png")
    SCTFUNC_backgroundImageRender = ImageTk.PhotoImage(SCTFUNC_backgroundImageImport)
    sctForm_Button = tkinter.Button(rootGUI, width=195, height=45, command=lambda:function_Tunnel(4, rootGUI), image=SCTFUNC_backgroundImageRender)
    sctForm_Button.image = SCTFUNC_backgroundImageRender
    sctForm_Button.place(x=250, y=105)

    #Periodic Table/Tab Function Button:
    PTFUNC_backgroundImageImport = Image.open(r"subMenu_PTBootButtonImage.png")
    PTFUNC_backgroundImageRender = ImageTk.PhotoImage(PTFUNC_backgroundImageImport)
    ptForm_Button = tkinter.Button(rootGUI, width=195, height=45, command=lambda:function_Tunnel(5, rootGUI), image=PTFUNC_backgroundImageRender)
    ptForm_Button.image = PTFUNC_backgroundImageRender
    ptForm_Button.place(x=250, y=185)

    #Physics Formula Function Button:
    PF_backgroundImageImport = Image.open(r"subMenu_PFBootButtonImage.png")
    PF_backgroundImageRender = ImageTk.PhotoImage(PF_backgroundImageImport)
    PF_Button = tkinter.Button(rootGUI, width=195, height=45, image=PF_backgroundImageRender, command=lambda:function_Tunnel(6, rootGUI))
    PF_Button.image = PF_backgroundImageRender
    PF_Button.place(x=250, y=265)

    #Webaite/Tab Function Button:
    WEBFUNC_backgroundImageImport = Image.open(r"subMenu_WebsiteImage.png")
    WEBFUNC_backgroundImageRender = ImageTk.PhotoImage(WEBFUNC_backgroundImageImport)
    WEBForm_Button = tkinter.Button(rootGUI, width=195, height=45, image=WEBFUNC_backgroundImageRender, command=lambda:website_Travel())
    WEBForm_Button.image = WEBFUNC_backgroundImageRender
    WEBForm_Button.place(x=140, y=345)

    #Footer:
    footer = tkinter.Label(rootGUI, text="More Functions available upon request.", bg="black", fg="white", font="Times 6")
    footer.place(x=-1, y=410)

    name = tkinter.Label(rootGUI, text="Pamal Mangat.", bg="black", fg="white", font="Times 6")
    name.place(x=419, y=410)

    rootGUI.title("[Function Menu]")
    rootGUI.geometry("475x425") #675x450 // Original.
    rootGUI.resizable(False, False)
    rootGUI.after(1, lambda: rootGUI.focus_force())
    rootGUI.iconbitmap(r'PMC_ICO.ico')
    rootGUI.mainloop()

    return 0
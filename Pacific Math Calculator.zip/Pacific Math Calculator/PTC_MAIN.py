
#Start/End Date: Friday March 17th, 2017.

import tkinter
from PIL import Image, ImageTk
from time import sleep
from benchScript import *
import webbrowser

def execute():

    def backPage(window):
        #Returned user to the previous window:
        window.destroy()
        window.quit()

        import PT_Main
        PT_Main.execute()

    def openWebPage(siteTag):

        if siteTag == 1:
            time.sleep(0.5)
            webbrowser.open("sciencenotes.org/printable-periodic-table/")

        elif siteTag == 2:
            time.sleep(0.5)
            webbrowser.open("pamalmangat.com/")

    tableGUI = tkinter.Tk()

    importBackground = Image.open(r"PTC_Background.png")
    renderBackground = ImageTk.PhotoImage(importBackground)
    displayBackground = tkinter.Label(tableGUI, image=renderBackground)
    displayBackground.image = renderBackground
    displayBackground.pack()

    #Courtesy Button: // Re-directs user back to the website containing the periodic table.
    importButtonSkin1 = Image.open(r"PTC_Courtesy_Button.png")
    renderButtonSkin1 = ImageTk.PhotoImage(importButtonSkin1)
    courtesyButton = tkinter.Button(tableGUI, image=renderButtonSkin1, command=lambda:openWebPage(1))
    courtesyButton.image = renderButtonSkin1
    courtesyButton.place(x=2, y=469)

    #Website Button: // Re-directs user back to PamalMangat.Com//.
    importButtonSkin2 = Image.open(r"PTC_Website_Button.png")
    renderButtonSkin2 = ImageTk.PhotoImage(importButtonSkin2)
    websiteButton = tkinter.Button(tableGUI, image=renderButtonSkin2, command=lambda:openWebPage(2))
    websiteButton.image = renderButtonSkin2
    websiteButton.place(x=400, y=469)

    #Back button:
    importButtonSkin3 = Image.open(r"SE_BackButton_Skin.png")
    renderButtonSkin3 = ImageTk.PhotoImage(importButtonSkin3)
    backButton = tkinter.Button(tableGUI, width=105, height=35, image=renderButtonSkin3, command=lambda:backPage(tableGUI))
    backButton.image = renderButtonSkin3
    backButton.place(x=775, y=473)

    tableGUI.geometry("900x525")
    tableGUI.title("Periodic Table: ")
    tableGUI.resizable(False, False)
    tableGUI.after(1, lambda: tableGUI.focus_force())
    tableGUI.iconbitmap(r'PMC_ICO.ico')
    tableGUI.mainloop()
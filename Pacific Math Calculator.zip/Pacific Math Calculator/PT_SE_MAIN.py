#Search Element Tab
#Start date : Wednesday, July 7th, 2016.
#End Date : Thursday, March 16th, 2017.

import tkinter
from PIL import Image, ImageTk
from time import sleep
from benchScript import *



def execute():

    global searchTag

    def backPage(window):
        #Returned user to the previous window:
        window.destroy()
        window.quit()

        import PT_Main
        PT_Main.execute()

    def helpPage():

        helpGUI = tkinter.Toplevel()

        def helpClose():
            helpGUI.quit()
            helpGUI.destroy()

        #Import background:
        importHelpBackground = Image.open(r"SE_Help_Background.png")
        renderHelpBackground = ImageTk.PhotoImage(importHelpBackground)
        displayHelpBackground = tkinter.Label(helpGUI, image=renderHelpBackground)
        displayHelpBackground.image = renderHelpBackground
        displayHelpBackground.pack()

        #Import close button:
        helpWindowCloseButton = tkinter.Button(helpGUI, text="Close!", width=12, height=2, font="Bizon 16", bg="Salmon", fg="Black", command=lambda:helpClose())
        helpWindowCloseButton.place(x=200, y=225)

        helpGUI.geometry("425x325")
        helpGUI.resizable(False, False)
        helpGUI.title("Help:")
        helpGUI.after(1, lambda: helpGUI.focus_force())
        helpGUI.iconbitmap(r'PMC_ICO.ico')
        helpGUI.mainloop()

    def resetPage():
        elementSymbol.config(text="")
        elementCharge.config(text="")
        elementGroup.config(text="")
        elementName.config(text="")
        atomicMass.config(text="")
        atomicNumber.config(text="")

        atomicMass.config(text="")
        atomicNumber.config(text="")
        elementSymbol.update()
        elementCharge.update()
        elementGroup.update()
        elementName.update()

        displayBackground.config(image=renderBackground)

    def searchLimit(*args):
        #Limits the ammount of characters entered into the search field to no more than 3:

        if len(searchTag.get()) > 3:
            searchTag.set(searchTag.get()[:3])
            SE_GUI.update()
            searchBar.focus()

    def search(userElement):
        #Function performs the search and display of results:

        try:

            #Check to see if what the user entered into the search field exists within the element dictionary:
            if userElement in elements:

                #Chnage the display:
                global renderBackground2

                importBackground2 = Image.open(r"SE_Answer_Background.png")
                renderBackground2 = ImageTk.PhotoImage(importBackground2)
                displayBackground.config(image=renderBackground2)

                #Function needed to be created in order to seperate multiple if,else statements:

                def display_Symbol():

                    if len(str(userElement)) == 1:
                        #Update the blank answers:
                        elementSymbol.config(text=str(userElement))
                        elementSymbol.place(x=370, y=160)

                    elif len(str(userElement)) == 2:
                        #Update the blank answers:
                        elementSymbol.config(text=str(userElement), underline=2)
                        elementSymbol.place(x=365, y=160)

                    return

                def display_Name():

                    if len(str(elements[userElement][3])) == 4:
                        #Display the element name:
                        elementName.config(text=str(elements[userElement][3]))
                        elementName.place(x=380, y=242)

                    elif len(str(elements[userElement][3])) <= 7 and len(str(elements[userElement][3])) > 4:
                        #Display the element name:
                        elementName.config(text=str(elements[userElement][3]))
                        elementName.place(x=360, y=242)

                    elif len(str(elements[userElement][3])) >= 8 and len(str(elements[userElement][3])) < 10:
                        #Display the element name:
                        elementName.config(text=str(elements[userElement][3]))
                        elementName.place(x=342, y=242)

                    elif len(str(elements[userElement][3])) >= 10 and len(str(elements[userElement][3])) < 14:
                        #Display the element name:
                        elementName.config(text=str(elements[userElement][3]))
                        elementName.place(x=335, y=242)


                    return

                def display_AtomicNumber():
                    atomicNumber.config(text=str(elements[userElement][0]))
                    atomicNumber.place(x=276, y=35)

                def display_AtomicMass():

                    if len(str(elements[userElement][1])) == 1:
                        atomicMass.config(text=str(elements[userElement][1]))
                        atomicMass.place(x=380, y=315)

                    elif len(str(elements[userElement][1])) == 2:
                        atomicMass.config(text=str(elements[userElement][1]))
                        atomicMass.place(x=370, y=315)

                    elif len(str(elements[userElement][1])) == 3:
                        atomicMass.config(text=str(elements[userElement][1]))
                        atomicMass.place(x=365, y=315)

                    elif len(str(elements[userElement][1])) == 4:
                        atomicMass.config(text=str(elements[userElement][1]))
                        atomicMass.place(x=350, y=315)

                    elif len(str(elements[userElement][1])) == 5:
                        atomicMass.config(text=str(elements[userElement][1]))
                        atomicMass.place(x=335, y=315)

                def display_ElementCharge():

                    if len(str(elements[userElement][2])) == 1:
                        elementCharge.config(text=str(elements[userElement][2]))
                        elementCharge.place(x=505, y=45)

                    elif len(str(elements[userElement][2])) == 2:
                        elementCharge.config(text=str(elements[userElement][2]))
                        elementCharge.place(x=500, y=45)

                    elif len(str(elements[userElement][2])) == 4:
                        elementCharge.config(text=str(elements[userElement][2]))
                        elementCharge.place(x=480, y=45)

                    elif len(str(elements[userElement][2])) == 5:
                        elementCharge.config(text=str(elements[userElement][2]))
                        elementCharge.place(x=480, y=45)

                    elif len(str(elements[userElement][2])) == 6:
                        elementCharge.config(text=str(elements[userElement][2]))
                        elementCharge.place(x=460, y=45)

                    elif len(str(elements[userElement][2])) == 10:
                        elementCharge.config(text=str(elements[userElement][2]))
                        elementCharge.place(x=470, y=45)

                def display_ElementGroup():
                    #Function displays the group that the element belongs to.

                    if elements[userElement][0] in alkali_Metals:
                        elementGroup.config(text="Alkali Metal")
                        elementGroup.place(x=284, y=100)

                    elif elements[userElement][0] in alkaline_Earth_Metals:
                        elementGroup.config(text="Alkaline Earth Metal")
                        elementGroup.place(x=284, y=100)

                    elif elements[userElement][0] in transition_Metals:
                        elementGroup.config(text="Transition Metal")
                        elementGroup.place(x=284, y=100)

                    elif elements[userElement][0] in metalloids:
                        elementGroup.config(text="Metalloid")
                        elementGroup.place(x=284, y=100)

                    elif elements[userElement][0] in non_Metals:
                        elementGroup.config(text="Non-Metal")
                        elementGroup.place(x=284, y=100)

                    elif elements[userElement][0] in other_Metals:
                        elementGroup.config(text="Other Metal")
                        elementGroup.place(x=284, y=100)

                    elif elements[userElement][0] in halogens:
                        elementGroup.config(text="Halogen")
                        elementGroup.place(x=284, y=100)

                    elif elements[userElement][0] in noble_Gases:
                        elementGroup.config(text="Noble Gas")
                        elementGroup.place(x=284, y=100)

                    elif elements[userElement][0] in hydrogen:
                        elementGroup.config(text="Hydrogen")
                        elementGroup.place(x=284, y=100)

                def exceptions():

                    if userElement == "Mg":
                        elementSymbol.config(text=str(userElement), underline=2)
                        elementSymbol.place(x=365, y=160)

                        elementName.config(text=str(elements[userElement][3]))
                        elementName.place(x=342, y=247)

                    elif userElement == "Sm":
                        elementSymbol.config(text=str(userElement), underline=2)
                        elementSymbol.place(x=350, y=160)

                        elementName.config(text=str(elements[userElement][3]))
                        elementName.place(x=342, y=247)

                    elif userElement == "Tm":
                        elementSymbol.config(text=str(userElement), underline=2)
                        elementSymbol.place(x=350, y=160)

                        elementName.config(text=str(elements[userElement][3]))
                        elementName.place(x=355, y=247)

                    elif userElement == "Pr":
                        elementName.config(text=str(elements[userElement][3]))
                        elementName.place(x=325, y=242)

                    elif userElement == "Sn" or "I" or "Br" or "Se" or "Pb":
                        elementCharge.config(text=str(elements[userElement][2]))
                        elementCharge.place(x=490, y=45)

                def exceptions_2():

                    if userElement == "Ir":
                        elementCharge.config(text=str(elements[userElement][2]))
                        elementCharge.place(x=480, y=45)

                    elif userElement == "Pt" or "Hg":
                        elementCharge.config(text=str(elements[userElement][2]))
                        elementCharge.place(x=480, y=45)

                def exceptions_3():

                    if userElement == "Db":
                        elementCharge.config(text=str(elements[userElement][2]))
                        elementCharge.place(x=505, y=45)

                def exceptions_4():
                    #A fourth function deals with elements with +2 letters.

                    if len(userElement) >= 3:
                        elementSymbol.config(text=str(userElement), underline=3)
                        elementSymbol.place(x=345, y=160)

                display_Name()
                display_Symbol()
                display_AtomicNumber()
                display_AtomicMass()
                display_ElementCharge()
                exceptions()
                exceptions_2()
                exceptions_3()
                exceptions_4()
                display_ElementGroup()

            else:

                errorGUI = tkinter.Toplevel()

                def errorClose():
                    errorGUI.quit()
                    errorGUI.destroy()

                #Import error background:
                importErrorBackground = Image.open(r"SE_Error_Background.png")
                renderErrorBackground = ImageTk.PhotoImage(importErrorBackground)
                displayErrorBackground = tkinter.Label(errorGUI, image=renderErrorBackground)
                displayErrorBackground.image = renderErrorBackground
                displayErrorBackground.place(x=-2,y=0)

                #Import Close Button:
                errorWindowCloseButton = tkinter.Button(errorGUI, text="Close!", width=6, height=1, font="Bizon 16", bg="Salmon", fg="Black", command=lambda:errorClose())
                errorWindowCloseButton.place(x=108, y=145)

                errorGUI.title("ERROR: ")
                errorGUI.geometry("300x200")
                errorGUI.resizable(False, False)
                errorGUI.after(100, lambda: errorGUI.focus_force())
                errorGUI.iconbitmap(r'PMC_ICO.ico')
                errorGUI.mainloop()

        except NameError or ValueError or SyntaxError as error_Catch:
            print("ERROR!")

    def entryKeyManager(event):

        if event.keysym == "Return":

            if len(searchBar.get()) == 0:

                errorGUI = tkinter.Toplevel()

                def errorClose():
                    errorGUI.quit()
                    errorGUI.destroy()

                #Import error background:
                importErrorBackground = Image.open(r"SE_Error_Background.png")
                renderErrorBackground = ImageTk.PhotoImage(importErrorBackground)
                displayErrorBackground = tkinter.Label(errorGUI, image=renderErrorBackground)
                displayErrorBackground.image = renderErrorBackground
                displayErrorBackground.place(x=-2,y=0)

                #Import Close Button:
                errorWindowCloseButton = tkinter.Button(errorGUI, text="Close!", width=6, height=1, font="Bizon 16", bg="Salmon", fg="Black", command=lambda:errorClose())
                errorWindowCloseButton.place(x=108, y=145)

                errorGUI.title("ERROR: ")
                errorGUI.geometry("300x200")
                errorGUI.resizable(False, False)
                errorGUI.after(100, lambda: errorGUI.focus_force())
                errorGUI.iconbitmap(r'PMC_ICO.ico')
                errorGUI.mainloop()

            else:
                search(searchBar.get())

        elif event.keysym == "Escape":

            elementSymbol.config(text="")
            elementCharge.config(text="")
            elementGroup.config(text="")
            elementName.config(text="")
            atomicMass.config(text="")
            atomicNumber.config(text="")

            atomicMass.config(text="")
            atomicNumber.config(text="")
            elementSymbol.update()
            elementCharge.update()
            elementGroup.update()
            elementName.update()

            displayBackground.config(image=renderBackground)


    #Dictionary containing all the elements data(atomic #, mass, charge, name)
    elements = {"H":(1, 1, "+1", "Hydrogen"),
                "He":(2, 4, "N", "Helium"),
                "Li":(3, 6.9, "+1", "Lithium"),
                "Be":(4, 9, "+2", "Beryllium"),
                "B":(5, 10.8, "+3", "Boron"),
                "C":(6, 12, "+/- 4", "Carbon"),
                "N":(7, 14, "+5,3", "Nitrogen"),
                "O":(8, 16, "-2", "Oxygen"),
                "F":(9, 19, "-1", "Flourine"),
                "Ne":(10, 20.2, "N", "Neon"),
                "Na":(11, 23, "+1", "Sodium"),
                "Mg":(12, 24.3, "+2", "Magnesium"),
                "Al":(13, 27, "+3", "Aluminum"),
                "Si":(14, 28.1, "+4", "Silicon"),
                "P":(15, 31, "+/- 3, \n+5", "Phosphorus"),
                "S":(16, 32.1, "-2", "Sulfur"),
                "Cl":(17, 35.5, "-1", "Chlorine"),
                "Ar":(18, 40, "N", "Argon"),
                "K":(19, 39.1, "+1", "Potassium"),
                "Ca":(20, 40.1, "+2", "Calcium"),
                "Sc":(21, 45, "+2", "Scandium"),
                "Ti":(22, 47.9, "+3", "Titanium"),
                "V":(23, 50.9, "+3,4,5", "Vanadium"),
                "Cr":(24, 52, "+2,3,6", "Chromium"),
                "Mn":(25, 55, "+2,4,7", "Manganese"),
                "Fe":(26, 55.9, "+2,3", "Iron"),
                "Co":(27, 58.9, "+2,3", "Cobalt"),
                "Ni":(28, 58.7, "+2", "Nickel"),
                "Cu":(29, 63.6, "+1,2", "Copper"),
                "Zn":(30, 65.4, "+2", "Zinc"),
                "Ga":(31, 69.7, "+3", "Gallium"),
                "Ge":(32, 72.6, "+4", "Germanium"),
                "As":(33, 74.9, "+3,5", "Arsenic"),
                "Se":(34, 79, "+4,\n-2", "Selenium"),
                "Br":(35, 79.9, "+5,\n-1", "Bromine"),
                "Kr":(36, 84.8, "N", "Krypton"),
                "Rb":(37, 84.5, "+1", "Rubidium"),
                "Sr":(38, 87.6, "+2", "Strontium"),
                "Y":(39, 88.9, "+3", "Yttrium"),
                "Zr":(40, 91.2, "+4", "Zirconium"),
                "Nb":(41, 93, "+5", "Niobium"),
                "Mo":(42, 96, "+4,6", "Molybdenum"),
                "Tc":(43, 99, "+4,7", "Technetium"),
                "Ru":(44, 101, "+3,4", "Ruthenium"),
                "Rh":(45, 103, "+3", "Rhodium"),
                "Pd":(46, 106.4, "+2,4", "Palladium"),
                "Ag":(47, 107.9, "+1", "Silver"),
                "Cd":(48, 112.4, "+2", "Cadmium"),
                "In":(49, 114.8, "+3", "Indium"),
                "Sn":(50, 118.7, "+2,\n-4", "Tin"),
                "Sb":(51, 121.8, "+3", "Antimony"),
                "Te":(52, 127.6, "+4", "Tellurium"),
                "I":(53, 126.9, "+5,\n-1", "Iodine"),
                "Xe":(54, 131.3, "N", "Xenon"),
                "Cs":(55, 132.9, "+1", "Cesium"),
                "Ba":(56, 137.3, "+2", "Barium"),
                "La":(57, 138.9, "+3", "Lanthanum"),
                "Ce":(58, 140.1, "+3", "Cerium"),
                "Pr":(59, 140.9, "+3", "Praseodymium"),
                "Nd":(60, 144.2, "+3", "Neodymium"),
                "Pm":(61, 144.9, "+3", "Promethium"),
                "Sm":(62, 150.4, "+3", "Samarium"),
                "Eu":(63, 152, "+3", "Europium"),
                "Gd":(64, 157.3, "+3", "Gadolinium"),
                "Tb":(65, 158.9, "+3", "Terbium"),
                "Dy":(66, 163, "+3", "Dysprosium"),
                "Ho":(67, 164, "+3", "Holmium"),
                "Er":(68, 167.3, "+3", "Erbium"),
                "Tm":(69, 168.9, "+3", "Thulium"),
                "Yb":(70, 173.1, "+3", "Ytterbium"),
                "Lu":(71, 175, "+3", "Lutetium"),
                "Hf":(72, 178.5, "+4", "Hafnium"),
                "Ta":(73, 181, "+5", "Tantalum"),
                "W":(74, 183.9, "+4,\n+6", "Tungsten"),
                "Re":(75, 186.2, "+3,\n+4,\n+5", "Rhenium"),
                "Os":(76, 190.2, "+4", "Osmium"),
                "Ir":(77, 192.2, "+3,4", "Iridium"),
                "Pt":(78, 195.1, "+2,4", "Platinum"),
                "Au":(79, 197, "+3", "Gold"),
                "Hg":(80, 200.6, "+1, 2", "Mercury"),
                "Tl":(81, 204.4, "+1,3", "Thallium"),
                "Pb":(82, 207.2, "+2", "Lead"),
                "Bi":(83, 209, "+3", "Bismuth"),
                "Po":(84, 209, "+4", "Polonium"),
                "At":(85, 209, "-1", "Astatine"),
                "Rn":(86, 222, "N", "Radon"),
                "Fr":(87, 223, "+1", "Francium"),
                "Ra":(88, 226, "+2", "Radium"),
                "Ac":(89, 227, "+3", "Actinium"),
                "Th":(90, 232, "+4", "Thorium"),
                "Pa":(91, 231, "+5", "Protactinium"),
                "U":(92, 238, "+6", "Uranium"),
                "Np":(93, 237, "+7", "Neptunium"),
                "Pu":(94, 244.1, "+4,7", "Plutonium"),
                "Am":(95, 243.1, "+3", "Americium"),
                "Cm":(96, 247.1, "+3", "Curium"),
                "Bk":(97, 247.1, "+3", "Berkelium"),
                "Cf":(98, 251.1, "+3", "Californium"),
                "Es":(99, 254, "+3", "Einsteinium"),
                "Fm":(100, 257.1, "+3", "Fermium"),
                "Md":(101, 258.1, "+3", "Mendelevium"),
                "No":(102, 259.1, "+2", "Nobelium"),
                "Lr":(103, 262, "+3", "Lawrencium"),
                "Rf":(104, 261, "+4", "Rutherfordium"),
                "Db":(105, 262, "?", "Dubnium"),
                "Sg":(106, 266, "?", "Seaborgium"),
                "Bh":(107, 264, "?", "Bohrium"),
                "Hs":(108, 269, "?", "Hassium"),
                "Mt":(109, 268, "?", "Meitnerium"),
                "Ds":(110, 269, "?", "Darmstadtium"),
                "Rg":(111, 272, "?", "Roentgenium"),
                "Cn":(112, 277, "?", "Copernicium"),
                "Uut":(113, 284, "?", "Ununtrium"),
                "Fl":(114, 289, "?", "Flerovium"),
                "Uup":(115, 288, "?", "Ununpentium"),
                "Lv":(116, 289, "?", "Livermorium"),
                "Uus":(117, 293, "?", "Ununseptium"),
                "Uuo":(118, 294, "?", "Ununoctium") }

    #Groups the elements in their respective groups based off their atomic number:
    alkali_Metals = [3,11,19,37,55,87]
    alkaline_Earth_Metals = [4,12,20,38,56,88]
    transition_Metals = [21,22,23,24,25,26,27,28,29,30,39,40,41,42,43,44,45,46,47,48,72,73,74,75,76,77,78,79,80,104,105,106,107,109,109,110,111,112]
    metalloids = [5,14,32,33,51,52,84]
    non_Metals = [6,7,8,15,16,34]
    other_Metals = [13,31,49,81,113,114,115,116,84,83,82,50]
    halogens = [9,17,35,53,85]
    noble_Gases = [2,10,18,36,54,86]
    hydrogen = [1]

    #Create an interactive display:
    SE_GUI = tkinter.Tk()

    #Sets up a background to be displayed within window:
    importBackground = Image.open(r"SE_Background.png")
    renderBackground = ImageTk.PhotoImage(importBackground)
    displayBackground = tkinter.Label(SE_GUI, image=renderBackground)
    displayBackground.image = renderBackground
    displayBackground.place(x=-2,y=0)

    #Set up an entry |"Search"| field:
    searchTag = tkinter.StringVar()
    searchBar = tkinter.Entry(SE_GUI, font="TimesNewRoman 28", width=5, bg="FireBrick2", fg="white", textvariable=searchTag)
    searchBar.focus()
    searchBar.place(x=42, y=104)

    #Search Button:
    importButtonSkin1 = Image.open(r"SE_SearchButton_Skin.png")
    renderButtonSkin1 = ImageTk.PhotoImage(importButtonSkin1)
    searchButton = tkinter.Button(SE_GUI, width=115, height=45, image=renderButtonSkin1, command=lambda:search(searchBar.get()))
    searchButton.image = renderButtonSkin1
    searchButton.place(x=35, y=170)

    #Refresh Button:
    importButtonSkin3 = Image.open(r"SE_RefreshButton_Skin.png")
    renderButtonSkin3 = ImageTk.PhotoImage(importButtonSkin3)
    refreshButton = tkinter.Button(SE_GUI, width=115, height=45, image=renderButtonSkin3, command=lambda:resetPage())
    refreshButton.image = renderButtonSkin3
    refreshButton.place(x=35, y=235)

    #Help Button:
    importButtonSkin2 = Image.open(r"SE_HelpButton_Skin.png")
    renderButtonSkin2 = ImageTk.PhotoImage(importButtonSkin2)
    helpButton = tkinter.Button(SE_GUI, width=115, height=45, image=renderButtonSkin2, command=lambda:helpPage())
    helpButton.image = renderButtonSkin2
    helpButton.place(x=35, y=300)

    #Back button:
    importButtonSkin4 = Image.open(r"SE_BackButton_Skin.png")
    renderButtonSkin4 = ImageTk.PhotoImage(importButtonSkin4)
    backButton = tkinter.Button(SE_GUI, width=105, height=35, image=renderButtonSkin4, command=lambda:backPage(SE_GUI))
    backButton.image = renderButtonSkin4
    backButton.place(x=1, y=380)

    #Blank Answer Display:
    elementSymbol = tkinter.Label(SE_GUI, text="", font="ComicSans 56", fg="White", bg="Black")
    elementName = tkinter.Label(SE_GUI, text="", font="ComicSans 20", fg="Snow3", bg="black")
    atomicNumber = tkinter.Label(SE_GUI, text="", font="ComicSans 36", fg="powderblue", bg="black")
    atomicMass = tkinter.Label(SE_GUI, text="", font="ComicSans 42", fg="rosybrown2", bg="black")
    elementCharge = tkinter.Label(SE_GUI, text="", font="ComicSans 18", fg="peachpuff3", bg="black")
    elementGroup = tkinter.Label(SE_GUI, text="Group Name", font="ComicSans 10", fg="White", bg="Black")

    #Tracing variables:
    searchTag.trace("w", searchLimit)

    #Bind Enter key to window:
    SE_GUI.bind("<Return>", entryKeyManager)

    #Bind Backspace to window:
    SE_GUI.bind("<Escape>", entryKeyManager)

    SE_GUI.geometry("575x425")
    SE_GUI.resizable(False, False)
    SE_GUI.after(1, lambda: SE_GUI.focus_force())
    SE_GUI.title("Element Search:")
    SE_GUI.iconbitmap(r'PMC_ICO.ico')
    SE_GUI.mainloop()



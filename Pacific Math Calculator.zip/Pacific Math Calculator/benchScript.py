#Script containing all the backup commands running in the back.
#This script was created to save space from the main scrips to import "light commands" into a separate script.

#Imports:
import tkinter
import time
import tkinter
import webbrowser

def transition(currentWindow, newWindow):
    #Function handles the transition between windows:
    time.sleep(1)
    currentWindow.destroy()
    currentWindow.quit()
    newWindow()

def function_Tunnel(lane, subMenuWindow):
    #Depending on the button clicked, a certain window is opened(function is runned):

    if lane == 1:
        print("Basic Calculator Function runned!")
        subMenuWindow.destroy()
        subMenuWindow.quit()
        time.sleep(1)
        import BC_Main
        BC_Main.execute()

    elif lane == 2:
        print("Quadtratic Function runned!")
        subMenuWindow.destroy()
        subMenuWindow.quit()
        time.sleep(1)
        import QFC_Main
        QFC_Main.execute()

    elif lane == 3:
        print("Square Root Function runned!")
        subMenuWindow.destroy()
        subMenuWindow.quit()
        time.sleep(1)
        import SQRT_MAIN
        SQRT_MAIN.execute()

    elif lane == 4:
        print("Square Root Function runned!")
        subMenuWindow.destroy()
        subMenuWindow.quit()
        time.sleep(1)
        import SCT_Main
        SCT_Main.execute()

    elif lane == 5:
        print("Chemistry Tab Function runned!")
        subMenuWindow.destroy()
        subMenuWindow.quit()
        time.sleep(1)
        import PT_Main
        PT_Main.execute()

    elif lane == 6:
        print("Physics Formula Tab Function runned!")
        subMenuWindow.destroy()
        subMenuWindow.quit()
        time.sleep(1)
        import PF_Main
        PF_Main.execute()


def homeTravel(currentWindow):
    #Function takes user back to the function select page:
    currentWindow.destroy()
    currentWindow.quit()
    import PMC_MAIN2
    time.sleep(1)
    PMC_MAIN2.rootGUI()

def quit_Application(currentWindow):
    time.sleep(1)
    currentWindow.destroy()
    currentWindow.quit()

def website_Travel():
    #Funcion allows the user to travel to my website:
    webbrowser.open("pamalmangat.com")



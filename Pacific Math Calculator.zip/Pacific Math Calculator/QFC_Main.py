#Quadratic Formula Calculator
#Author : Pamal Mangat.
# #Start date : Thursday, March 31st, 2016.

#CLICKING THE QUADTRATIC BUTTON BRINGS YOU HERE!

import tkinter
from PIL import Image, ImageTk
from math import sqrt, log
from time import sleep
from benchScript import *
from decimal import *
import math


def execute():

    def calculate(a,b,c):

        def closeTab(whichWindow):
            whichWindow.destroy()
            whichWindow.quit()

        def check_Key(event):

            #Checks if a certain key has been pressed by the user:

            #if enter key was pressed, run the calculate function:
            if event.keysym == "Return":
                closeTab(displayGUI)

        #Function calculates the answer:

        #Try to calculate the answer and display it:
        try:

            A = float((a))
            B = float((b))
            C = float((c))

            #Root 1 answer:
            x1 = ((-B) + (B**2 - 4*A*C)**0.5)/(2*A)

            #Root 2 answer:
            x2 = ((-B) - (B**2 - 4*A*C)**0.5)/(2*A)

            #Round the answers:
            root1 = (math.ceil((x1.real+x1.imag)*100)/100)
            root2 = (math.ceil((x2.real+x2.imag)*100)/100)

            if (B**2 - 4*A*C) > 0 :
                roots = "2 Real Roots"

            elif (B**2 - 4*A*C) == 0 :
                roots = "1 Real Root"

            elif (B**2 - 4*A*C) < 0 :
                roots = "No Real Roots"

            displayGUI = tkinter.Toplevel()

            #Imports a backgrond image/template:
            templateImport = Image.open(r"QFC_AnswerSkin.png")
            templateRender = ImageTk.PhotoImage(templateImport)
            templateDisplay = tkinter.Label(displayGUI, image=templateRender)
            templateDisplay.image = templateRender
            templateDisplay.pack()

            #Printing the X1 to the window:
            x1Display = tkinter.Label(displayGUI, text=root1, font="TimesNewRoman 22", bg="White", fg="Red")
            x1Display.place(x=47, y=15)

            #Printing the X2 to the window:
            x2Display = tkinter.Label(displayGUI, text=root2, font="TimesNewRoman 22", bg="White", fg="Red")
            x2Display.place(x=47, y=68)

            rootsDisplay = tkinter.Label(displayGUI, text=roots, font="TimesNewRoman 12", bg="White", fg="Red")
            rootsDisplay.place(x=47, y=130)

            #Creates a button than (when clicked) closes the answer tab:
            closeButtonSkinImport = Image.open(r"QFC_AnswerCloseButtonSkin.png")
            closeButtonSkinRender = ImageTk.PhotoImage(closeButtonSkinImport)
            closeButton = tkinter.Button(displayGUI, image=closeButtonSkinRender, command=lambda:closeTab(displayGUI))
            closeButton.image = closeButtonSkinRender
            closeButton.focus()
            closeButton.place(x=192, y=122)

            displayGUI.title("Answer:")
            displayGUI.bind("<Return>", check_Key)
            displayGUI.geometry("300x175")
            displayGUI.resizable(False, False)
            displayGUI.after(1, lambda: displayGUI.focus_force())
            displayGUI.iconbitmap(r'PMC_ICO.ico')
            displayGUI.mainloop()

        #If an error is encountered than notify the user:
        except ValueError as VE:

            def closeTab(whichWindow):
                whichWindow.destroy()
                whichWindow.quit()

            def check_Key(event):

                #Checks if a certain key has been pressed by the user:

                #if enter key was pressed, run the calculate function:
                if event.keysym == "Return":
                    closeTab(errorGUI)

            errorGUI = tkinter.Toplevel()

            #Imports a backgrond image/template:
            templateImport = Image.open(r"QFC_ErrorSkin.png")
            templateRender = ImageTk.PhotoImage(templateImport)
            templateDisplay = tkinter.Label(errorGUI, image=templateRender)
            templateDisplay.image = templateRender
            templateDisplay.pack()

            #Creates a button than (when clicked) closes the answer tab:
            closeButtonSkinImport = Image.open(r"QFC_AnswerCloseButtonSkin.png")
            closeButtonSkinRender = ImageTk.PhotoImage(closeButtonSkinImport)
            closeButton = tkinter.Button(errorGUI, image=closeButtonSkinRender, command=lambda:closeTab(errorGUI))
            closeButton.image = closeButtonSkinRender
            closeButton.focus()
            closeButton.place(x=186, y=122)

            errorGUI.title("Uh-Oh!")
            errorGUI.geometry("300x175")
            errorGUI.resizable(False, False)
            errorGUI.after(1, lambda: errorGUI.focus_force())
            errorGUI.bind("<Return>", check_Key)
            errorGUI.iconbitmap(r'PMC_ICO.ico')
            errorGUI.mainloop()

    def clear():
        #Clear all the entries:
        a_Store.set("")
        b_Store.set("")
        c_Store.set("")
        #Sets focus back to the first entry:
        b1Tab.focus()

    def helpTab():
        #More information and tips for the user are displayed in a new window:

        def closeTab(whichWindow):
            whichWindow.destroy()
            whichWindow.quit()

        def check_Key(event):

            #Checks if a certain key has been pressed by the user:

            #if enter key was pressed, run the calculate function:
            if event.keysym == "Return":
                closeTab(helpGUI)


        helpGUI = tkinter.Toplevel()

        #Imports a backgrond image/template:
        templateImport = Image.open(r"QFC_HelpSkin.png")
        templateRender = ImageTk.PhotoImage(templateImport)
        templateDisplay = tkinter.Label(helpGUI, image=templateRender)
        templateDisplay.image = templateRender
        templateDisplay.pack()

        #Creates a button than (when clicked) closes the answer tab:
        closeButtonSkinImport = Image.open(r"QFC_AnswerCloseButtonSkin.png")
        closeButtonSkinRender = ImageTk.PhotoImage(closeButtonSkinImport)
        closeButton = tkinter.Button(helpGUI, image=closeButtonSkinRender, command=lambda:closeTab(helpGUI))
        closeButton.image = closeButtonSkinRender
        closeButton.focus()
        closeButton.place(x=290, y=322)

        helpGUI.title("Having trouble?")
        helpGUI.geometry("450x400")
        helpGUI.resizable(False ,False)
        helpGUI.bind("<Return>", check_Key)
        helpGUI.iconbitmap(r'PMC_ICO.ico')
        helpGUI.mainloop()

    class check_Entry:
        #Class/Function handles the focus and limits fields/entries:

        def a_Entry_Limit(*args):
            #Limits the amount of characters entered in the entries:

            if len(a_Store.get()) >= 4:
                a_Store.set(a_Store.get()[:4])
                baseGUI.update()
                cTab.focus()

        def b_Entry_Limit(*args):
            #Limits the amount of characters entered in the entries:

            #List used to check for valid entries:

            if len(b_Store.get()) >= 4:
                b_Store.set(b_Store.get()[:4])
                baseGUI.update()
                a1Tab.focus()

        def c_Entry_Limit(*args):
            #Limits the amount of characters entered in the entries:

            if len(c_Store.get()) >= 4:
                c_Store.set(c_Store.get()[:4])
                baseGUI.update()
                b1Tab.focus()
                baseGUI.update()

        def b_EntryColor(*args):

            if len(b_Store.get()) >= 1 :
                b1Tab.config(bg="Snow", fg="Black")
                b2Tab.config(bg="Snow", fg="Black")

        def a_EntryColor(*args):

            if len(a_Store.get()) >= 1 :
                a1Tab.config(bg="Snow", fg="Black")
                a2Tab.config(bg="Snow", fg="Black")

        def c_EntryColor(*args):

            if len(c_Store.get()) >= 1 :
                cTab.config(bg="Snow", fg="Black")
                cTab.config(bg="Snow", fg="Black")

        def check_Key(event):

            #Checks if a certain key has been pressed by the user:

            #if enter key was pressed, run the calculate function:
            if event.keysym == "Return":
                calculate(a1Tab.get(), b1Tab.get(), cTab.get())

    #The main window:
    global a_Store
    global b_Store
    global c_Store
    baseGUI = tkinter.Tk()

    #Imports a backgrond image/template:
    templateImport = Image.open(r"QFC_template.png")
    templateRender = ImageTk.PhotoImage(templateImport)
    templateDisplay = tkinter.Label(baseGUI, image=templateRender)
    templateDisplay.image = templateRender
    templateDisplay.pack()

    #b1 entry:
    b_Store = tkinter.StringVar()
    b1Tab = tkinter.Entry(baseGUI, font="Comic 26", width=3, bg="PeachPuff2", fg="firebrick2", textvariable=b_Store)
    b1Tab.focus()
    b1Tab.place(x=133, y=118)

    #b2 entry:
    b2Tab = tkinter.Entry(baseGUI, font="Comic 26", width=3, bg="PeachPuff2", fg="firebrick2", textvariable=b_Store)
    b2Tab.place(x=282, y=117)

    #a1 entry:
    a_Store = tkinter.StringVar()
    a1Tab = tkinter.Entry(baseGUI, font="Comic 26", width=3, bg="PeachPuff2", fg="firebrick2", textvariable=a_Store)
    a1Tab.place(x=424, y=117)

    #c entry:
    c_Store = tkinter.StringVar()
    cTab = tkinter.Entry(baseGUI, font="Comic 26", width=3, bg="PeachPuff2", fg="firebrick2", textvariable=c_Store)
    cTab.place(x=515, y=117)

    #a2 entry:
    a2Tab = tkinter.Entry(baseGUI, font="Comic 26", width=3, bg="PeachPuff2", fg="firebrick2", textvariable=a_Store)
    a2Tab.place(x=329, y=192)

    #Equal button:
    equalsButtonSkinImport = Image.open(r"QFC_equalsButtonSkin.png")
    equalsButtonSkinRender = ImageTk.PhotoImage(equalsButtonSkinImport)
    equalsButton = tkinter.Button(baseGUI, bg="LightYellow2", fg="Red", image=equalsButtonSkinRender, width=163, height=53, command=lambda:calculate(a1Tab.get(), b1Tab.get(), cTab.get()))
    equalsButton.place(x=425, y=305)

    #Clear button:
    clearButtonSkinImport = Image.open(r"QFC_clearButtonSkin.png")
    clearButtonSkinRender = ImageTk.PhotoImage(clearButtonSkinImport)
    clearButton = tkinter.Button(baseGUI, bg="LightYellow2", fg="Red", image=clearButtonSkinRender, width=163, height=53, command=lambda:clear())
    clearButton.place(x=230, y=305)

    #Home Button:
    homeButtonSkinImport = Image.open(r"homeButtonSkin.png")
    homeButtonSkinRender = ImageTk.PhotoImage(homeButtonSkinImport)
    homeButton = tkinter.Button(baseGUI, bg="LightYellow2", fg="Red", image=homeButtonSkinRender, width=50, height=50, command=lambda:homeTravel(baseGUI))
    homeButton.place(x=35, y=305)

    #Help Button:
    helpButtonSkinImport = Image.open(r"helpButtonSkin.png")
    helpButtonSkinRender = ImageTk.PhotoImage(helpButtonSkinImport)
    helpButton = tkinter.Button(baseGUI, bg="LightYellow2", fg="Red", image=helpButtonSkinRender, width=50, height=50, command=lambda:helpTab())
    helpButton.place(x=111, y=305)

    #Observes the entries:
    a_Store.trace("w", check_Entry.a_Entry_Limit)
    b_Store.trace("w", check_Entry.b_Entry_Limit)
    c_Store.trace("w", check_Entry.c_Entry_Limit)
    b_Store.trace("w", check_Entry.b_EntryColor)
    a_Store.trace("w", check_Entry.a_EntryColor)
    c_Store.trace("w", check_Entry.c_EntryColor)

    baseGUI.title("Quadratic Formula Calculator")
    baseGUI.bind("<Return>", check_Entry.check_Key)
    baseGUI.geometry("625x415")
    baseGUI.resizable(False, False)
    baseGUI.after(1, lambda: baseGUI.focus_force())
    baseGUI.iconbitmap(r'PMC_ICO.ico')
    baseGUI.mainloop()

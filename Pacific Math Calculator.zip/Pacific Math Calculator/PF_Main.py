#Start Date: Tuesday, July 11th, 2017.
#Author : Pamal Mangat.

import tkinter
from PIL import Image, ImageTk
import math
from time import sleep
from benchScript import *

def execute():
    rootGUI = tkinter.Tk()

    #Background image:
    importBackground = Image.open(r"PF_Background.png")
    renderBackground = ImageTk.PhotoImage(importBackground)
    displayBackground = tkinter.Label(rootGUI, image=renderBackground)
    displayBackground.image = renderBackground
    displayBackground.pack()

    #Formula 1 Buton:
    formulaOneBTNImageImport = Image.open(r"PF_KE_Button.png")
    formulaOneBTNImageRender = ImageTk.PhotoImage(formulaOneBTNImageImport)
    formulaOneButton = tkinter.Button(rootGUI, image=formulaOneBTNImageRender, command=lambda:transition(rootGUI, kinematics))
    formulaOneBTNImageRender.image = formulaOneBTNImageRender
    formulaOneButton.config(width=290, height=74)
    formulaOneButton.place(x=20, y=125)

    #Formula 2 Buton:
    formulaTwoBTNImageImport = Image.open(r"PF_CS_Button.png")
    formulaTwoBTNImageRender = ImageTk.PhotoImage(formulaTwoBTNImageImport)
    formulaTwoButton = tkinter.Button(rootGUI, image=formulaTwoBTNImageRender)
    formulaTwoBTNImageRender.image = formulaTwoBTNImageRender
    formulaTwoButton.config(width=290, height=74)
    formulaTwoButton.place(x=20, y=225)

    #Formula 3 Buton:
    formulaThreeBTNImageImport = Image.open(r"PF_CS_Button.png")
    formulaThreeBTNImageRender = ImageTk.PhotoImage(formulaThreeBTNImageImport)
    formulaThreeButton = tkinter.Button(rootGUI, image=formulaThreeBTNImageRender)
    formulaThreeBTNImageRender.image = formulaThreeBTNImageRender
    formulaThreeButton.config(width=290, height=74)
    formulaThreeButton.place(x=335, y=125)

    #Formula 4 Buton:
    formulaFourBTNImageImport = Image.open(r"PF_CS_Button.png")
    formulaFourBTNImageRender = ImageTk.PhotoImage(formulaFourBTNImageImport)
    formulaFourButton = tkinter.Button(rootGUI, image=formulaFourBTNImageRender)
    formulaFourBTNImageRender.image = formulaFourBTNImageRender
    formulaFourButton.config(width=290, height=74)
    formulaFourButton.place(x=335, y=225)

    #Home Button:
    homeButtonSkinImport = Image.open(r"homeButtonSkin.png")
    homeButtonSkinRender = ImageTk.PhotoImage(homeButtonSkinImport)
    homeButton = tkinter.Button(rootGUI, bg="LightYellow2", fg="Red", image=homeButtonSkinRender, width=50, height=50, command=lambda:homeTravel(rootGUI))
    homeButton.place(x=575, y=40)

    rootGUI.geometry("650x425")
    rootGUI.resizable(False, False)
    rootGUI.title("Physics Formulas:")
    rootGUI.iconbitmap(r'PMC_ICO.ico')
    rootGUI.after(100, lambda: rootGUI.focus_force())
    rootGUI.mainloop()

def kinematics():

    #Class is created to monitor the entry values:
    class check_Entry:

        def velocityFinal_Entry_Limit(*args):
            #Limits the amount of characters entered in the entries:

            if len(finalVelocity_Store.get()) >= 3:
                finalVelocity_Store.set(finalVelocity_Store.get()[:3])
                kinematic_Delta.update()
                initialVelocity_Tab.focus()

        def velocityInitial_Entry_Limit(*args):
            #Limits the amount of characters entered in the entries:

            if len(initialVelocity_Store.get()) >= 3:
                initialVelocity_Store.set(initialVelocity_Store.get()[:3])
                kinematic_Delta.update()
                acceleration_Tab.focus()

        def acceleration_Entry_Limit(*args):
            #Limits the amount of characters entered in the entries:

            if len(acceleration_Store.get()) >= 3:
                acceleration_Store.set(acceleration_Store.get()[:3])
                kinematic_Delta.update()
                time_Tab.focus()

        def time_Entry_Limit(*args):
            #Limits the amount of characters entered in the entries:

            if len(time_Store.get()) >= 3:
                time_Store.set(time_Store.get()[:3])
                kinematic_Delta.update()

    #Function revolves around Kinematic Category:

    kinematic_Delta = tkinter.Tk()

    #Imports a backgrond image/template:
    templateImport = Image.open(r"PF_KE_Background.png")
    templateRender = ImageTk.PhotoImage(templateImport)
    templateDisplay = tkinter.Label(kinematic_Delta, image=templateRender)
    templateDisplay.image = templateRender
    templateDisplay.pack()

    #Back button:
    importButtonSkin4 = Image.open(r"SE_BackButton_Skin.png")
    renderButtonSkin4 = ImageTk.PhotoImage(importButtonSkin4)
    backButton = tkinter.Button(kinematic_Delta, width=105, height=35, image=renderButtonSkin4)
    backButton.image = renderButtonSkin4
    backButton.place(x=665, y=22)

    #Home Button:
    homeButtonSkinImport = Image.open(r"homeButtonSkin.png")
    homeButtonSkinRender = ImageTk.PhotoImage(homeButtonSkinImport)
    homeButton = tkinter.Button(kinematic_Delta, bg="LightYellow2", fg="Red", image=homeButtonSkinRender, width=50, height=50, command=lambda:homeTravel(kinematic_Delta))
    homeButton.place(x=785, y=15)

    #Entry box containing formula # 1 (VF = VI + AT):
    #VF box:
    finalVelocity_Store = tkinter.StringVar()
    finalVelocity_Tab = tkinter.Entry(kinematic_Delta, font="Comic 26", width=3, bg="lightslateblue", fg="snow", textvariable=finalVelocity_Store)
    finalVelocity_Tab.focus()
    finalVelocity_Tab.place(x=25, y=55)

    #VI box:
    initialVelocity_Store = tkinter.StringVar()
    initialVelocity_Tab = tkinter.Entry(kinematic_Delta, font="Comic 26", width=3, bg="lightslateblue", fg="snow", textvariable=initialVelocity_Store)
    initialVelocity_Tab.focus()
    initialVelocity_Tab.place(x=135, y=55)

    #A box:
    acceleration_Store = tkinter.StringVar()
    acceleration_Tab = tkinter.Entry(kinematic_Delta, font="Comic 26", width=3, bg="lightslateblue", fg="snow", textvariable=acceleration_Store)
    acceleration_Tab.focus()
    acceleration_Tab.place(x=245, y=55)

    #AT box:
    time_Store = tkinter.StringVar()
    time_Tab = tkinter.Entry(kinematic_Delta, font="Comic 26", width=3, bg="lightslateblue", fg="snow", textvariable=time_Store)
    time_Tab.focus()
    time_Tab.place(x=355, y=55)

    #Tracing:
    finalVelocity_Store.trace("w", check_Entry.velocityFinal_Entry_Limit)
    initialVelocity_Store.trace("w", check_Entry.velocityInitial_Entry_Limit)
    acceleration_Store.trace("w", check_Entry.acceleration_Entry_Limit)
    time_Store.trace("w", check_Entry.time_Entry_Limit)

    kinematic_Delta.title("Kinematic Equations:")
    kinematic_Delta.geometry("850x525")
    kinematic_Delta.resizable(False, False)
    kinematic_Delta.iconbitmap(r'PMC_ICO.ico')
    kinematic_Delta.after(100, lambda: kinematic_Delta.focus_force())
    kinematic_Delta.mainloop()

kinematics()
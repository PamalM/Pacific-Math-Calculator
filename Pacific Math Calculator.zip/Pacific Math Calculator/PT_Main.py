#Start Date: Tuesday, July 5th, 2016.
#Author : Pamal Mangat.

import tkinter
from PIL import Image, ImageTk
import math
from time import sleep
from benchScript import *



def execute():

    def determine_Path(button_Pass, window):
        #Function determines which button was pressed; out of the two:

        if button_Pass == 1:
            window.destroy()
            window.quit()

            time.sleep(1)

            import PT_SE_MAIN
            PT_SE_MAIN.execute()

        else:
            window.destroy()
            window.quit()

            time.sleep(1)

            import PTC_MAIN
            PTC_MAIN.execute()

    PT_GUI = tkinter.Tk()

    #Sets up a background to be displayed in the function window:
    importBackground = Image.open(r"PT_Background.png")
    renderBackground = ImageTk.PhotoImage(importBackground)
    displayBackground = tkinter.Label(PT_GUI, image=renderBackground)
    displayBackground.image = renderBackground
    displayBackground.place(x=0,y=0)

    #Sets up a "Search Element" Button:
    elementBTNImageImport = Image.open(r"PT_ESB1_Background.png")
    elementBTNImageRender = ImageTk.PhotoImage(elementBTNImageImport)
    elementSearchButton = tkinter.Button(PT_GUI, image=elementBTNImageRender, command=lambda:determine_Path(1, PT_GUI))
    elementBTNImageRender.image = elementBTNImageRender
    elementSearchButton.config(width=290, height=74)
    elementSearchButton.place(x=25, y=145)

    #Sets up a "Periodic Table" Button:
    periodicTableBTNImageImport = Image.open(r"PT_ESB2_Background.png")
    periodicTableBTNImageRender = ImageTk.PhotoImage(periodicTableBTNImageImport)
    periodicTableButton = tkinter.Button(PT_GUI, image=periodicTableBTNImageRender, command=lambda:determine_Path(not 1, PT_GUI))
    periodicTableBTNImageRender.image = periodicTableBTNImageRender
    periodicTableButton.config(width=290, height=74)
    periodicTableButton.place(x=25, y=245)

    #Home Button:
    homeButtonSkinImport = Image.open(r"homeButtonSkin.png")
    homeButtonSkinRender = ImageTk.PhotoImage(homeButtonSkinImport)
    homeButton = tkinter.Button(PT_GUI, bg="LightYellow2", fg="Red", image=homeButtonSkinRender, width=50, height=50, command=lambda:homeTravel(PT_GUI))
    homeButton.place(x=525, y=335)

    PT_GUI.title("Chemistry Function:")
    PT_GUI.geometry("600x425")
    PT_GUI.resizable(False, False)
    PT_GUI.after(100, lambda: PT_GUI.focus_force())
    PT_GUI.iconbitmap(r'PMC_ICO.ico')
    PT_GUI.mainloop()

